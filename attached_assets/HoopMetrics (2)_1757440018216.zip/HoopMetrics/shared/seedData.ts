import { initialWorkoutData } from "@/lib/workoutData";
import type { IStorage } from "../server/storage";

export async function initializeData(storage: IStorage) {
  try {
    // Check if data already exists
    const existingCategories = await storage.getWorkoutCategories();
    if (existingCategories.length > 0) {
      console.log("Data already initialized, skipping seed");
      return;
    }

    console.log("Initializing workout data...");

    // Create categories
    const categoryMap = new Map();
    for (const categoryData of initialWorkoutData.categories) {
      const category = await storage.createWorkoutCategory(categoryData);
      categoryMap.set(categoryData.name, category.id);
    }

    // Create workouts and exercises
    for (const workoutData of initialWorkoutData.workouts) {
      const categoryId = categoryMap.get(workoutData.category);
      if (!categoryId) continue;

      const workout = await storage.createWorkout({
        name: workoutData.name,
        description: workoutData.description,
        categoryId,
        duration: workoutData.duration,
        difficulty: workoutData.difficulty,
        isPopular: workoutData.isPopular,
      });

      // Create exercises for this workout
      for (const exerciseData of workoutData.exercises) {
        await storage.createExercise({
          workoutId: workout.id,
          name: exerciseData.name,
          description: exerciseData.description,
          sets: exerciseData.sets,
          reps: exerciseData.reps,
          duration: exerciseData.duration,
          restTime: exerciseData.restTime,
          order: exerciseData.order,
          instructions: exerciseData.instructions,
          tips: exerciseData.tips,
        });
      }
    }

    // Create achievements
    for (const achievementData of initialWorkoutData.achievements) {
      await storage.createAchievement(achievementData);
    }

    console.log("Workout data initialized successfully");
  } catch (error) {
    console.error("Error initializing workout data:", error);
  }
}
