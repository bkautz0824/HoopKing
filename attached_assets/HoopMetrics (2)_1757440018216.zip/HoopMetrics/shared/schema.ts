import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  real,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Workout categories (Gym vs Court)
export const workoutCategories = pgTable("workout_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  icon: varchar("icon"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Individual workouts
export const workouts = pgTable("workouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  categoryId: varchar("category_id").notNull().references(() => workoutCategories.id),
  duration: integer("duration").notNull(), // in minutes
  difficulty: varchar("difficulty").notNull(), // beginner, intermediate, advanced
  imageUrl: varchar("image_url"),
  isPopular: boolean("is_popular").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Exercises within workouts
export const exercises = pgTable("exercises", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workoutId: varchar("workout_id").notNull().references(() => workouts.id),
  name: varchar("name").notNull(),
  description: text("description"),
  sets: integer("sets"),
  reps: integer("reps"),
  duration: integer("duration"), // in seconds
  restTime: integer("rest_time"), // in seconds
  order: integer("order").notNull(),
  instructions: text("instructions"),
  tips: text("tips"),
  createdAt: timestamp("created_at").defaultNow(),
});

// User workout sessions
export const workoutSessions = pgTable("workout_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  workoutId: varchar("workout_id").notNull().references(() => workouts.id),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  totalDuration: integer("total_duration"), // actual time spent in minutes
  status: varchar("status").notNull().default("in_progress"), // in_progress, completed, paused
});

// Exercise performance within sessions
export const exercisePerformance = pgTable("exercise_performance", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().references(() => workoutSessions.id),
  exerciseId: varchar("exercise_id").notNull().references(() => exercises.id),
  setsCompleted: integer("sets_completed").default(0),
  repsCompleted: integer("reps_completed").default(0),
  actualDuration: integer("actual_duration"), // in seconds
  notes: text("notes"),
  completed: boolean("completed").default(false),
});

// User achievements
export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  icon: varchar("icon"),
  type: varchar("type").notNull(), // streak, milestone, performance
  requirement: integer("requirement"), // threshold value
  category: varchar("category"), // shooting, conditioning, etc.
});

// User earned achievements
export const userAchievements = pgTable("user_achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  achievementId: varchar("achievement_id").notNull().references(() => achievements.id),
  earnedAt: timestamp("earned_at").defaultNow(),
  progress: integer("progress").default(0),
});

// User stats tracking
export const userStats = pgTable("user_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  date: timestamp("date").defaultNow(),
  workoutsCompleted: integer("workouts_completed").default(0),
  totalWorkoutTime: integer("total_workout_time").default(0), // in minutes
  shotsAttempted: integer("shots_attempted").default(0),
  shotsMade: integer("shots_made").default(0),
  freeThrowsAttempted: integer("free_throws_attempted").default(0),
  freeThrowsMade: integer("free_throws_made").default(0),
  threePointsAttempted: integer("three_points_attempted").default(0),
  threePointsMade: integer("three_points_made").default(0),
  currentStreak: integer("current_streak").default(0),
  longestStreak: integer("longest_streak").default(0),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  workoutSessions: many(workoutSessions),
  userAchievements: many(userAchievements),
  userStats: many(userStats),
}));

export const workoutCategoriesRelations = relations(workoutCategories, ({ many }) => ({
  workouts: many(workouts),
}));

export const workoutsRelations = relations(workouts, ({ one, many }) => ({
  category: one(workoutCategories, {
    fields: [workouts.categoryId],
    references: [workoutCategories.id],
  }),
  exercises: many(exercises),
  sessions: many(workoutSessions),
}));

export const exercisesRelations = relations(exercises, ({ one, many }) => ({
  workout: one(workouts, {
    fields: [exercises.workoutId],
    references: [workouts.id],
  }),
  performances: many(exercisePerformance),
}));

export const workoutSessionsRelations = relations(workoutSessions, ({ one, many }) => ({
  user: one(users, {
    fields: [workoutSessions.userId],
    references: [users.id],
  }),
  workout: one(workouts, {
    fields: [workoutSessions.workoutId],
    references: [workouts.id],
  }),
  performances: many(exercisePerformance),
}));

export const exercisePerformanceRelations = relations(exercisePerformance, ({ one }) => ({
  session: one(workoutSessions, {
    fields: [exercisePerformance.sessionId],
    references: [workoutSessions.id],
  }),
  exercise: one(exercises, {
    fields: [exercisePerformance.exerciseId],
    references: [exercises.id],
  }),
}));

export const achievementsRelations = relations(achievements, ({ many }) => ({
  userAchievements: many(userAchievements),
}));

export const userAchievementsRelations = relations(userAchievements, ({ one }) => ({
  user: one(users, {
    fields: [userAchievements.userId],
    references: [users.id],
  }),
  achievement: one(achievements, {
    fields: [userAchievements.achievementId],
    references: [achievements.id],
  }),
}));

export const userStatsRelations = relations(userStats, ({ one }) => ({
  user: one(users, {
    fields: [userStats.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true });
export const insertWorkoutCategorySchema = createInsertSchema(workoutCategories).omit({ id: true, createdAt: true });
export const insertWorkoutSchema = createInsertSchema(workouts).omit({ id: true, createdAt: true });
export const insertExerciseSchema = createInsertSchema(exercises).omit({ id: true, createdAt: true });
export const insertWorkoutSessionSchema = createInsertSchema(workoutSessions).omit({ id: true });
export const insertExercisePerformanceSchema = createInsertSchema(exercisePerformance).omit({ id: true });
export const insertAchievementSchema = createInsertSchema(achievements).omit({ id: true });
export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({ id: true });
export const insertUserStatsSchema = createInsertSchema(userStats).omit({ id: true });

// === ENHANCED FEATURES ===

// Wearable device integration
export const wearableDevices = pgTable("wearable_devices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  deviceType: varchar("device_type").notNull(), // 'apple_watch', 'garmin', 'coros'
  deviceModel: varchar("device_model"),
  deviceId: varchar("device_id").notNull(),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  lastSync: timestamp("last_sync"),
  isActive: boolean("is_active").default(true),
  permissions: jsonb("permissions"), // JSON: permissions granted
  createdAt: timestamp("created_at").defaultNow(),
});

export const wearableData = pgTable("wearable_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  deviceId: varchar("device_id").references(() => wearableDevices.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  sessionId: varchar("session_id").references(() => workoutSessions.id),
  
  // Core biometrics
  heartRateData: jsonb("heart_rate_data"), // JSON time-series
  caloriesBurned: integer("calories_burned"),
  activeCalories: integer("active_calories"),
  steps: integer("steps"),
  distance: real("distance"),
  
  // Advanced metrics
  vo2Max: real("vo2_max"),
  heartRateZones: jsonb("heart_rate_zones"), // JSON
  recoveryHeartRate: integer("recovery_heart_rate"),
  hrv: real("hrv"),
  
  // Basketball-specific calculated metrics
  effortScore: real("effort_score"), // AI-calculated 1-10
  intensityDistribution: jsonb("intensity_distribution"), // JSON
  fatigueIndicator: real("fatigue_indicator"),
  
  recordedAt: timestamp("recorded_at").notNull(),
  syncedAt: timestamp("synced_at").defaultNow(),
});

// Enhanced exercise categorization
export const exerciseCategories = pgTable("exercise_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  methodology: varchar("methodology"), // 'traditional', 'goata', 'functional'
  parentCategoryId: varchar("parent_category_id"),
  color: varchar("color").default("#3B82F6"),
  icon: varchar("icon"),
  sortOrder: integer("sort_order").default(0),
  isActive: boolean("is_active").default(true),
  createdBy: varchar("created_by").default("system"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const exerciseTags = pgTable("exercise_tags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  category: varchar("category"), // 'muscle_group', 'movement_pattern', 'skill'
  color: varchar("color"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Enhanced exercises table (new version with more features)
export const exercisesEnhanced = pgTable("exercises_enhanced", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  
  // Basic info (similar to current structure)
  name: varchar("name").notNull(),
  description: text("description").notNull(),
  categoryId: varchar("category_id").references(() => exerciseCategories.id),
  
  // Detailed specifications
  instructions: jsonb("instructions").notNull(), // Step-by-step JSON array
  setupInstructions: text("setup_instructions"),
  safetyNotes: text("safety_notes"),
  equipmentRequired: jsonb("equipment_required"), // JSON array
  equipmentOptional: jsonb("equipment_optional"), // JSON array
  
  // Exercise parameters
  difficultyLevel: varchar("difficulty_level").notNull(), // beginner/intermediate/advanced
  durationType: varchar("duration_type").notNull(), // reps/time/distance
  defaultSets: integer("default_sets").default(3),
  defaultReps: integer("default_reps"),
  defaultDuration: integer("default_duration"), // seconds
  defaultRestTime: integer("default_rest_time").default(60),
  intensityLevel: integer("intensity_level").notNull(), // 1-10
  
  // Basketball-specific attributes
  positionFocus: jsonb("position_focus"), // JSON: ['guard', 'forward', 'center']
  skillDevelopment: jsonb("skill_development"), // JSON: skills this develops
  gameSituationRelevance: jsonb("game_situation_relevance"), // JSON
  
  // GOATA methodology integration
  movementPatterns: jsonb("movement_patterns"), // JSON array
  chainIntegration: jsonb("chain_integration"), // JSON: which chains
  goataPrinciples: jsonb("goata_principles"), // JSON array
  movementQualityFocus: jsonb("movement_quality_focus"), // JSON array
  
  // Coaching and AI data
  coachingCues: jsonb("coaching_cues"), // JSON array
  commonMistakes: jsonb("common_mistakes"), // JSON array
  troubleshootingTips: jsonb("troubleshooting_tips"), // JSON array
  successIndicators: jsonb("success_indicators"), // JSON array
  
  // Progression system
  prerequisiteExercises: jsonb("prerequisite_exercises"), // JSON array of IDs
  progressionExercises: jsonb("progression_exercises"), // JSON array
  regressionExercises: jsonb("regression_exercises"), // JSON array
  
  // Media
  primaryVideoUrl: varchar("primary_video_url"),
  demonstrationVideos: jsonb("demonstration_videos"), // JSON array
  referenceImages: jsonb("reference_images"), // JSON array
  
  // Analytics
  usageCount: integer("usage_count").default(0),
  averageRating: real("average_rating"),
  effectivenessScore: real("effectiveness_score"), // AI-calculated
  
  // Metadata
  createdBy: varchar("created_by").notNull(),
  source: varchar("source"), // 'user_input', 'expert_curated', 'ai_generated'
  isVerified: boolean("is_verified").default(false),
  isPublic: boolean("is_public").default(true),
  isCustom: boolean("is_custom").default(false),
  version: integer("version").default(1),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Many-to-many relationship for tags
export const exerciseToTags = pgTable("exercise_to_tags", {
  exerciseId: varchar("exercise_id").references(() => exercisesEnhanced.id),
  tagId: varchar("tag_id").references(() => exerciseTags.id),
}, (table) => ({
  pk: index("exercise_tag_idx").on(table.exerciseId, table.tagId),
}));

// User workout preferences and AI personalization
export const userWorkoutPreferences = pgTable("user_workout_preferences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  
  // Athletic profile
  skillLevel: varchar("skill_level").notNull(), // beginner/intermediate/advanced
  primaryPosition: varchar("primary_position"), // guard/forward/center
  secondaryPositions: jsonb("secondary_positions"), // JSON array
  playingStyle: varchar("playing_style"), // athletic/technical/cerebral
  experienceYears: integer("experience_years"),
  
  // Physical profile
  height: integer("height"), // cm
  weight: real("weight"), // kg
  injuryHistory: jsonb("injury_history"), // JSON array (anonymized)
  currentLimitations: jsonb("current_limitations"), // JSON array
  
  // Goals and training preferences
  primaryGoals: jsonb("primary_goals").notNull(), // JSON array
  secondaryGoals: jsonb("secondary_goals"), // JSON array
  workoutFrequency: integer("workout_frequency"), // per week
  sessionDurationPreference: integer("session_duration_preference"), // minutes
  intensityPreference: integer("intensity_preference").default(7), // 1-10
  
  // Equipment and environment
  availableEquipment: jsonb("available_equipment"), // JSON array
  trainingLocations: jsonb("training_locations"), // JSON array
  preferredWorkoutTimes: jsonb("preferred_workout_times"), // JSON array
  
  // Methodology preferences
  methodologyWeights: jsonb("methodology_weights"), // JSON: weights for different approaches
  goataExperienceLevel: varchar("goata_experience_level"), // none/beginner/intermediate/advanced
  plyometricReadiness: varchar("plyometric_readiness"), // none/basic/intermediate/advanced
  
  // AI learning data (evolves with usage)
  completedWorkouts: jsonb("completed_workouts"), // JSON: performance history
  favoriteExercises: jsonb("favorite_exercises"), // JSON array of exercise IDs
  avoidedExercises: jsonb("avoided_exercises"), // JSON array
  
  // Wearable integration preferences
  wearableTargets: jsonb("wearable_targets"), // JSON: HR zones, calorie targets, etc.
  
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Future video integration (prepare schema now)
export const workoutVideos = pgTable("workout_videos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => workoutSessions.id),
  exerciseLogId: varchar("exercise_log_id").references(() => exercisePerformance.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  
  videoUrl: varchar("video_url").notNull(),
  videoDuration: integer("video_duration"), // seconds
  videoSize: integer("video_size"), // bytes
  
  // Future AI analysis results
  formAnalysis: jsonb("form_analysis"), // JSON: AI form analysis
  repCountDetected: integer("rep_count_detected"),
  qualityScore: real("quality_score"), // 0-100
  feedback: text("feedback"), // AI-generated feedback
  
  processingStatus: varchar("processing_status").default("pending"), // pending/processing/completed/failed
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  processedAt: timestamp("processed_at"),
});

// AI workout generation metadata
export const aiWorkoutTemplates = pgTable("ai_workout_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  userProfileCriteria: jsonb("user_profile_criteria").notNull(), // JSON: when to use this template
  workoutStructure: jsonb("workout_structure").notNull(), // JSON: phases, timing, etc.
  exerciseSelectionCriteria: jsonb("exercise_selection_criteria"), // JSON: filters and weights
  tags: jsonb("tags"), // JSON array
  difficulty: varchar("difficulty").notNull(), // beginner/intermediate/advanced
  estimatedDuration: integer("estimated_duration"), // minutes
  createdBy: varchar("created_by").default("ai"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// === ENHANCED RELATIONS ===
export const wearableDevicesRelations = relations(wearableDevices, ({ one, many }) => ({
  user: one(users, {
    fields: [wearableDevices.userId],
    references: [users.id],
  }),
  data: many(wearableData),
}));

export const wearableDataRelations = relations(wearableData, ({ one }) => ({
  device: one(wearableDevices, {
    fields: [wearableData.deviceId],
    references: [wearableDevices.id],
  }),
  user: one(users, {
    fields: [wearableData.userId],
    references: [users.id],
  }),
  session: one(workoutSessions, {
    fields: [wearableData.sessionId],
    references: [workoutSessions.id],
  }),
}));

export const exerciseCategoriesRelations = relations(exerciseCategories, ({ one, many }) => ({
  parent: one(exerciseCategories, {
    fields: [exerciseCategories.parentCategoryId],
    references: [exerciseCategories.id],
  }),
  children: many(exerciseCategories),
  exercises: many(exercisesEnhanced),
}));

export const exerciseTagsRelations = relations(exerciseTags, ({ many }) => ({
  exerciseToTags: many(exerciseToTags),
}));

export const exercisesEnhancedRelations = relations(exercisesEnhanced, ({ one, many }) => ({
  category: one(exerciseCategories, {
    fields: [exercisesEnhanced.categoryId],
    references: [exerciseCategories.id],
  }),
  exerciseToTags: many(exerciseToTags),
}));

export const exerciseToTagsRelations = relations(exerciseToTags, ({ one }) => ({
  exercise: one(exercisesEnhanced, {
    fields: [exerciseToTags.exerciseId],
    references: [exercisesEnhanced.id],
  }),
  tag: one(exerciseTags, {
    fields: [exerciseToTags.tagId],
    references: [exerciseTags.id],
  }),
}));

export const userWorkoutPreferencesRelations = relations(userWorkoutPreferences, ({ one }) => ({
  user: one(users, {
    fields: [userWorkoutPreferences.userId],
    references: [users.id],
  }),
}));

export const workoutVideosRelations = relations(workoutVideos, ({ one }) => ({
  session: one(workoutSessions, {
    fields: [workoutVideos.sessionId],
    references: [workoutSessions.id],
  }),
  exerciseLog: one(exercisePerformance, {
    fields: [workoutVideos.exerciseLogId],
    references: [exercisePerformance.id],
  }),
  user: one(users, {
    fields: [workoutVideos.userId],
    references: [users.id],
  }),
}));

// === ENHANCED INSERT SCHEMAS ===
export const insertWearableDeviceSchema = createInsertSchema(wearableDevices).omit({ id: true, createdAt: true });
export const insertWearableDataSchema = createInsertSchema(wearableData).omit({ id: true, syncedAt: true });
export const insertExerciseCategorySchema = createInsertSchema(exerciseCategories).omit({ id: true, createdAt: true });
export const insertExerciseTagSchema = createInsertSchema(exerciseTags).omit({ id: true, createdAt: true });
export const insertExerciseEnhancedSchema = createInsertSchema(exercisesEnhanced).omit({ id: true, createdAt: true, updatedAt: true });
export const insertUserWorkoutPreferencesSchema = createInsertSchema(userWorkoutPreferences).omit({ id: true, updatedAt: true });
export const insertWorkoutVideoSchema = createInsertSchema(workoutVideos).omit({ id: true, uploadedAt: true });
export const insertAiWorkoutTemplateSchema = createInsertSchema(aiWorkoutTemplates).omit({ id: true, createdAt: true, updatedAt: true });

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type WorkoutCategory = typeof workoutCategories.$inferSelect;
export type Workout = typeof workouts.$inferSelect;
export type Exercise = typeof exercises.$inferSelect;
export type WorkoutSession = typeof workoutSessions.$inferSelect;
export type ExercisePerformance = typeof exercisePerformance.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
export type UserStats = typeof userStats.$inferSelect;

// Enhanced types
export type WearableDevice = typeof wearableDevices.$inferSelect;
export type WearableData = typeof wearableData.$inferSelect;
export type ExerciseCategory = typeof exerciseCategories.$inferSelect;
export type ExerciseTag = typeof exerciseTags.$inferSelect;
export type ExerciseEnhanced = typeof exercisesEnhanced.$inferSelect;
export type UserWorkoutPreferences = typeof userWorkoutPreferences.$inferSelect;
export type WorkoutVideo = typeof workoutVideos.$inferSelect;
export type AiWorkoutTemplate = typeof aiWorkoutTemplates.$inferSelect;

export type InsertWorkoutCategory = z.infer<typeof insertWorkoutCategorySchema>;
export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;
export type InsertWorkoutSession = z.infer<typeof insertWorkoutSessionSchema>;
export type InsertExercisePerformance = z.infer<typeof insertExercisePerformanceSchema>;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;

// Enhanced insert types
export type InsertWearableDevice = z.infer<typeof insertWearableDeviceSchema>;
export type InsertWearableData = z.infer<typeof insertWearableDataSchema>;
export type InsertExerciseCategory = z.infer<typeof insertExerciseCategorySchema>;
export type InsertExerciseTag = z.infer<typeof insertExerciseTagSchema>;
export type InsertExerciseEnhanced = z.infer<typeof insertExerciseEnhancedSchema>;
export type InsertUserWorkoutPreferences = z.infer<typeof insertUserWorkoutPreferencesSchema>;
export type InsertWorkoutVideo = z.infer<typeof insertWorkoutVideoSchema>;
export type InsertAiWorkoutTemplate = z.infer<typeof insertAiWorkoutTemplateSchema>;
