import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { AlertCircle, CheckCircle, Plus, Trash2, Save, Eye, Lightbulb, Target, Dumbbell, Users, Brain, Video, Star } from 'lucide-react';

interface ExerciseFormData {
  // Step 1: Basic Information
  name: string;
  description: string;
  categoryId: string;
  difficultyLevel: 'beginner' | 'intermediate' | 'advanced' | '';
  
  // Step 2: Exercise Mechanics
  instructions: string[];
  setupInstructions: string;
  safetyNotes: string;
  durationType: 'reps' | 'time' | 'distance' | '';
  defaultSets: number;
  defaultReps: number | null;
  defaultDuration: number | null;
  defaultRestTime: number;
  intensityLevel: number;
  
  // Step 3: Basketball Context
  positionFocus: string[];
  skillDevelopment: string[];
  gameSituationRelevance: string[];
  
  // Step 4: GOATA Integration
  movementPatterns: string[];
  chainIntegration: string[];
  goataPrinciples: string[];
  movementQualityFocus: string[];
  
  // Step 5: Coaching Intelligence
  coachingCues: string[];
  commonMistakes: string[];
  troubleshootingTips: string[];
  successIndicators: string[];
  
  // Step 6: Equipment & Environment
  equipmentRequired: string[];
  equipmentOptional: string[];
  
  // Step 7: Progression System
  prerequisiteExercises: string[];
  progressionExercises: string[];
  regressionExercises: string[];
  
  // Step 8: Media & Review
  primaryVideoUrl: string;
  demonstrationVideos: string[];
  referenceImages: string[];
}

interface ValidationError {
  field: string;
  message: string;
  severity: 'error' | 'warning' | 'info';
}

const basketballPositions = [
  'Point Guard', 'Shooting Guard', 'Small Forward', 'Power Forward', 'Center'
];

const skillAreas = [
  'Shooting', 'Ball Handling', 'Passing', 'Defense', 'Rebounding', 
  'Footwork', 'Conditioning', 'Strength', 'Agility', 'Court Vision'
];

const gameSituations = [
  'Fast Break', 'Half Court Offense', 'Pick and Roll', 'Post Play', 'Transition Defense',
  'Man-to-Man Defense', 'Zone Defense', 'Free Throw Situations', 'End Game', 'Press Break'
];

const goataMovements = [
  'Forward Chain', 'Posterior Chain', 'Lateral Chain', 'Rotational Patterns',
  'Deceleration', 'Multi-planar Movement', 'Core Integration', 'Hip Mobility'
];

const equipmentOptions = [
  'Basketball', 'Dumbbells', 'Resistance Bands', 'Medicine Ball', 'Agility Ladder',
  'Cones', 'Plyometric Box', 'Pull-up Bar', 'Battle Ropes', 'Kettlebell',
  'Foam Roller', 'Balance Board', 'Speed Parachute', 'Weighted Vest'
];

export function ExerciseCollectionWizard({ onComplete, onCancel }: { 
  onComplete: (exercise: any) => void;
  onCancel: () => void;
}) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<ExerciseFormData>({
    name: '',
    description: '',
    categoryId: '',
    difficultyLevel: '',
    instructions: [''],
    setupInstructions: '',
    safetyNotes: '',
    durationType: '',
    defaultSets: 3,
    defaultReps: null,
    defaultDuration: null,
    defaultRestTime: 60,
    intensityLevel: 5,
    positionFocus: [],
    skillDevelopment: [],
    gameSituationRelevance: [],
    movementPatterns: [],
    chainIntegration: [],
    goataPrinciples: [],
    movementQualityFocus: [],
    coachingCues: [''],
    commonMistakes: [''],
    troubleshootingTips: [''],
    successIndicators: [''],
    equipmentRequired: [],
    equipmentOptional: [],
    prerequisiteExercises: [],
    progressionExercises: [],
    regressionExercises: [],
    primaryVideoUrl: '',
    demonstrationVideos: [],
    referenceImages: []
  });

  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ['/api/exercises/categories'],
  });

  // Get suggestions based on current data
  const { data: suggestions = {} } = useQuery({
    queryKey: ['/api/exercises/suggestions', formData.categoryId],
    enabled: !!formData.categoryId,
  });

  // Save exercise mutation
  const saveExerciseMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest('POST', '/api/exercises/enhanced', data);
    },
    onSuccess: () => {
      toast({
        title: 'Exercise Created!',
        description: 'Your exercise has been successfully added to the database.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/exercises'] });
      onComplete(formData);
    },
    onError: () => {
      toast({
        title: 'Save Failed',
        description: 'Failed to save the exercise. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const steps = [
    { id: 1, title: 'Basic Info', description: 'Name, category, difficulty', icon: Target, required: true },
    { id: 2, title: 'Mechanics', description: 'How to perform the exercise', icon: Dumbbell, required: true },
    { id: 3, title: 'Basketball Context', description: 'Position and skill relevance', icon: Users, required: false },
    { id: 4, title: 'GOATA Integration', description: 'Movement patterns and chains', icon: Brain, required: false },
    { id: 5, title: 'Coaching Intelligence', description: 'Cues, mistakes, and tips', icon: Lightbulb, required: true },
    { id: 6, title: 'Equipment', description: 'Required and optional equipment', icon: Dumbbell, required: true },
    { id: 7, title: 'Progression', description: 'Prerequisites and progressions', icon: Star, required: false },
    { id: 8, title: 'Media & Review', description: 'Videos, images, and final review', icon: Video, required: false }
  ];

  const validateCurrentStep = () => {
    const errors: ValidationError[] = [];
    
    switch (currentStep) {
      case 1:
        if (!formData.name.trim()) {
          errors.push({ field: 'name', message: 'Exercise name is required', severity: 'error' });
        } else if (formData.name.length < 3) {
          errors.push({ field: 'name', message: 'Name should be at least 3 characters', severity: 'warning' });
        }
        
        if (!formData.description.trim()) {
          errors.push({ field: 'description', message: 'Description is required', severity: 'error' });
        } else if (formData.description.length < 20) {
          errors.push({ field: 'description', message: 'Description should be more detailed (20+ characters)', severity: 'warning' });
        }
        
        if (!formData.categoryId) {
          errors.push({ field: 'categoryId', message: 'Category selection is required', severity: 'error' });
        }
        
        if (!formData.difficultyLevel) {
          errors.push({ field: 'difficultyLevel', message: 'Difficulty level is required', severity: 'error' });
        }
        break;
        
      case 2:
        if (formData.instructions.filter(i => i.trim()).length === 0) {
          errors.push({ field: 'instructions', message: 'At least one instruction step is required', severity: 'error' });
        }
        
        if (!formData.durationType) {
          errors.push({ field: 'durationType', message: 'Duration type is required', severity: 'error' });
        }
        
        if (formData.durationType === 'reps' && !formData.defaultReps) {
          errors.push({ field: 'defaultReps', message: 'Default reps required for rep-based exercises', severity: 'error' });
        }
        
        if (formData.durationType === 'time' && !formData.defaultDuration) {
          errors.push({ field: 'defaultDuration', message: 'Default duration required for time-based exercises', severity: 'error' });
        }
        break;
        
      case 5:
        if (formData.coachingCues.filter(c => c.trim()).length === 0) {
          errors.push({ field: 'coachingCues', message: 'At least one coaching cue is recommended', severity: 'warning' });
        }
        break;
    }
    
    setValidationErrors(errors);
    return errors.filter(e => e.severity === 'error').length === 0;
  };

  const addToArray = (field: keyof ExerciseFormData, value: string) => {
    const current = formData[field] as string[];
    if (value.trim() && !current.includes(value.trim())) {
      setFormData(prev => ({
        ...prev,
        [field]: [...current, value.trim()]
      }));
    }
  };

  const removeFromArray = (field: keyof ExerciseFormData, index: number) => {
    const current = formData[field] as string[];
    setFormData(prev => ({
      ...prev,
      [field]: current.filter((_, i) => i !== index)
    }));
  };

  const updateArrayAtIndex = (field: keyof ExerciseFormData, index: number, value: string) => {
    const current = formData[field] as string[];
    const updated = [...current];
    updated[index] = value;
    setFormData(prev => ({ ...prev, [field]: updated }));
  };

  const getStepProgress = () => {
    return ((currentStep - 1) / steps.length) * 100;
  };

  const canProceedToNextStep = () => {
    const currentStepData = steps[currentStep - 1];
    if (currentStepData.required) {
      return validateCurrentStep();
    }
    return true;
  };

  const handleNext = () => {
    if (canProceedToNextStep()) {
      setCurrentStep(Math.min(steps.length, currentStep + 1));
    }
  };

  const handlePrevious = () => {
    setCurrentStep(Math.max(1, currentStep - 1));
  };

  const handleSave = () => {
    if (validateCurrentStep()) {
      // Transform data to match schema
      const exerciseData = {
        name: formData.name,
        description: formData.description,
        categoryId: formData.categoryId,
        instructions: formData.instructions.filter(i => i.trim()),
        setupInstructions: formData.setupInstructions,
        safetyNotes: formData.safetyNotes,
        equipmentRequired: formData.equipmentRequired,
        equipmentOptional: formData.equipmentOptional,
        difficultyLevel: formData.difficultyLevel,
        durationType: formData.durationType,
        defaultSets: formData.defaultSets,
        defaultReps: formData.defaultReps,
        defaultDuration: formData.defaultDuration,
        defaultRestTime: formData.defaultRestTime,
        intensityLevel: formData.intensityLevel,
        positionFocus: formData.positionFocus,
        skillDevelopment: formData.skillDevelopment,
        gameSituationRelevance: formData.gameSituationRelevance,
        movementPatterns: formData.movementPatterns,
        chainIntegration: formData.chainIntegration,
        goataPrinciples: formData.goataPrinciples,
        movementQualityFocus: formData.movementQualityFocus,
        coachingCues: formData.coachingCues.filter(c => c.trim()),
        commonMistakes: formData.commonMistakes.filter(m => m.trim()),
        troubleshootingTips: formData.troubleshootingTips.filter(t => t.trim()),
        successIndicators: formData.successIndicators.filter(s => s.trim()),
        prerequisiteExercises: formData.prerequisiteExercises,
        progressionExercises: formData.progressionExercises,
        regressionExercises: formData.regressionExercises,
        primaryVideoUrl: formData.primaryVideoUrl,
        demonstrationVideos: formData.demonstrationVideos,
        referenceImages: formData.referenceImages,
        createdBy: 'user',
        source: 'user_input',
        isVerified: false,
        isPublic: true,
        isCustom: false,
        version: 1
      };
      
      saveExerciseMutation.mutate(exerciseData);
    }
  };

  useEffect(() => {
    validateCurrentStep();
  }, [formData, currentStep]);

  const renderStepIndicator = () => (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Step {currentStep} of {steps.length}</h2>
        <div className="text-sm text-muted-foreground">{Math.round(getStepProgress())}% Complete</div>
      </div>
      
      <Progress value={getStepProgress()} className="mb-4" />
      
      <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <div
              key={step.id}
              className={`p-2 rounded text-center text-xs transition-colors cursor-pointer ${
                currentStep === step.id
                  ? 'bg-orange-500 text-white'
                  : currentStep > step.id
                  ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                  : step.required
                  ? 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
                  : 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'
              }`}
              onClick={() => step.id <= currentStep && setCurrentStep(step.id)}
            >
              <Icon className="h-4 w-4 mx-auto mb-1" />
              <div className="font-medium">{step.title}</div>
              {step.required && <div className="text-xs opacity-75">*</div>}
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Exercise Name *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="e.g., Form Shooting Close Range"
          data-testid="input-exercise-name"
        />
      </div>

      <div>
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Describe what this exercise accomplishes and its benefits..."
          rows={3}
          data-testid="input-exercise-description"
        />
      </div>

      <div>
        <Label htmlFor="categoryId">Category *</Label>
        <Select value={formData.categoryId} onValueChange={(value) => setFormData(prev => ({ ...prev, categoryId: value }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select exercise category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category: any) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="difficultyLevel">Difficulty Level *</Label>
        <Select value={formData.difficultyLevel} onValueChange={(value) => setFormData(prev => ({ ...prev, difficultyLevel: value as any }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select difficulty level" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="beginner">Beginner</SelectItem>
            <SelectItem value="intermediate">Intermediate</SelectItem>
            <SelectItem value="advanced">Advanced</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-4">
      <div>
        <Label>Exercise Instructions *</Label>
        <div className="space-y-2">
          {formData.instructions.map((instruction, index) => (
            <div key={index} className="flex gap-2">
              <Input
                value={instruction}
                onChange={(e) => updateArrayAtIndex('instructions', index, e.target.value)}
                placeholder={`Step ${index + 1}: Describe the action...`}
                className="flex-1"
              />
              {formData.instructions.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => removeFromArray('instructions', index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setFormData(prev => ({ ...prev, instructions: [...prev.instructions, ''] }))}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Step
          </Button>
        </div>
      </div>

      <div>
        <Label htmlFor="setupInstructions">Setup Instructions</Label>
        <Textarea
          id="setupInstructions"
          value={formData.setupInstructions}
          onChange={(e) => setFormData(prev => ({ ...prev, setupInstructions: e.target.value }))}
          placeholder="Describe how to set up for this exercise..."
          rows={2}
        />
      </div>

      <div>
        <Label htmlFor="safetyNotes">Safety Notes</Label>
        <Textarea
          id="safetyNotes"
          value={formData.safetyNotes}
          onChange={(e) => setFormData(prev => ({ ...prev, safetyNotes: e.target.value }))}
          placeholder="Any safety considerations or warnings..."
          rows={2}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="durationType">Duration Type *</Label>
          <Select value={formData.durationType} onValueChange={(value) => setFormData(prev => ({ ...prev, durationType: value as any }))}>
            <SelectTrigger>
              <SelectValue placeholder="How is this measured?" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="reps">Repetitions</SelectItem>
              <SelectItem value="time">Time Duration</SelectItem>
              <SelectItem value="distance">Distance</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="defaultSets">Default Sets</Label>
          <Input
            id="defaultSets"
            type="number"
            value={formData.defaultSets}
            onChange={(e) => setFormData(prev => ({ ...prev, defaultSets: parseInt(e.target.value) || 3 }))}
            min="1"
            max="10"
          />
        </div>
      </div>

      {formData.durationType === 'reps' && (
        <div>
          <Label htmlFor="defaultReps">Default Reps *</Label>
          <Input
            id="defaultReps"
            type="number"
            value={formData.defaultReps || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, defaultReps: parseInt(e.target.value) || null }))}
            placeholder="e.g., 10"
          />
        </div>
      )}

      {formData.durationType === 'time' && (
        <div>
          <Label htmlFor="defaultDuration">Default Duration (seconds) *</Label>
          <Input
            id="defaultDuration"
            type="number"
            value={formData.defaultDuration || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, defaultDuration: parseInt(e.target.value) || null }))}
            placeholder="e.g., 30"
          />
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="defaultRestTime">Rest Time (seconds)</Label>
          <Input
            id="defaultRestTime"
            type="number"
            value={formData.defaultRestTime}
            onChange={(e) => setFormData(prev => ({ ...prev, defaultRestTime: parseInt(e.target.value) || 60 }))}
          />
        </div>

        <div>
          <Label>Intensity Level: {formData.intensityLevel}/10</Label>
          <Slider
            value={[formData.intensityLevel]}
            onValueChange={(value) => setFormData(prev => ({ ...prev, intensityLevel: value[0] }))}
            max={10}
            min={1}
            step={1}
            className="mt-2"
          />
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-4">
      <div>
        <Label>Position Focus</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {basketballPositions.map((position) => (
            <div key={position} className="flex items-center space-x-2">
              <Checkbox
                id={position}
                checked={formData.positionFocus.includes(position)}
                onCheckedChange={() => {
                  if (formData.positionFocus.includes(position)) {
                    setFormData(prev => ({
                      ...prev,
                      positionFocus: prev.positionFocus.filter(p => p !== position)
                    }));
                  } else {
                    addToArray('positionFocus', position);
                  }
                }}
              />
              <Label htmlFor={position} className="text-sm">{position}</Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label>Skill Development Areas</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {skillAreas.map((skill) => (
            <div key={skill} className="flex items-center space-x-2">
              <Checkbox
                id={skill}
                checked={formData.skillDevelopment.includes(skill)}
                onCheckedChange={() => {
                  if (formData.skillDevelopment.includes(skill)) {
                    setFormData(prev => ({
                      ...prev,
                      skillDevelopment: prev.skillDevelopment.filter(s => s !== skill)
                    }));
                  } else {
                    addToArray('skillDevelopment', skill);
                  }
                }}
              />
              <Label htmlFor={skill} className="text-sm">{skill}</Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label>Game Situation Relevance</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {gameSituations.map((situation) => (
            <div key={situation} className="flex items-center space-x-2">
              <Checkbox
                id={situation}
                checked={formData.gameSituationRelevance.includes(situation)}
                onCheckedChange={() => {
                  if (formData.gameSituationRelevance.includes(situation)) {
                    setFormData(prev => ({
                      ...prev,
                      gameSituationRelevance: prev.gameSituationRelevance.filter(s => s !== situation)
                    }));
                  } else {
                    addToArray('gameSituationRelevance', situation);
                  }
                }}
              />
              <Label htmlFor={situation} className="text-sm">{situation}</Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-4">
      <Alert>
        <Brain className="h-4 w-4" />
        <AlertDescription>
          GOATA (Greatest Of All Time Athlete) methodology focuses on movement quality and injury prevention through proper chain integration.
        </AlertDescription>
      </Alert>

      <div>
        <Label>Movement Patterns</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {goataMovements.map((pattern) => (
            <div key={pattern} className="flex items-center space-x-2">
              <Checkbox
                id={pattern}
                checked={formData.movementPatterns.includes(pattern)}
                onCheckedChange={() => {
                  if (formData.movementPatterns.includes(pattern)) {
                    setFormData(prev => ({
                      ...prev,
                      movementPatterns: prev.movementPatterns.filter(p => p !== pattern)
                    }));
                  } else {
                    addToArray('movementPatterns', pattern);
                  }
                }}
              />
              <Label htmlFor={pattern} className="text-sm">{pattern}</Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderStep5 = () => (
    <div className="space-y-4">
      <div>
        <Label>Coaching Cues</Label>
        <div className="space-y-2">
          {formData.coachingCues.map((cue, index) => (
            <div key={index} className="flex gap-2">
              <Input
                value={cue}
                onChange={(e) => updateArrayAtIndex('coachingCues', index, e.target.value)}
                placeholder="What should the athlete focus on?"
                className="flex-1"
              />
              {formData.coachingCues.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => removeFromArray('coachingCues', index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setFormData(prev => ({ ...prev, coachingCues: [...prev.coachingCues, ''] }))}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Cue
          </Button>
        </div>
      </div>

      <div>
        <Label>Common Mistakes</Label>
        <div className="space-y-2">
          {formData.commonMistakes.map((mistake, index) => (
            <div key={index} className="flex gap-2">
              <Input
                value={mistake}
                onChange={(e) => updateArrayAtIndex('commonMistakes', index, e.target.value)}
                placeholder="What do athletes often do wrong?"
                className="flex-1"
              />
              {formData.commonMistakes.length > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => removeFromArray('commonMistakes', index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setFormData(prev => ({ ...prev, commonMistakes: [...prev.commonMistakes, ''] }))}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Mistake
          </Button>
        </div>
      </div>
    </div>
  );

  const renderStep6 = () => (
    <div className="space-y-4">
      <div>
        <Label>Required Equipment</Label>
        <div className="grid grid-cols-3 gap-2 mt-2">
          {equipmentOptions.map((equipment) => (
            <div key={equipment} className="flex items-center space-x-2">
              <Checkbox
                id={`req-${equipment}`}
                checked={formData.equipmentRequired.includes(equipment)}
                onCheckedChange={() => {
                  if (formData.equipmentRequired.includes(equipment)) {
                    setFormData(prev => ({
                      ...prev,
                      equipmentRequired: prev.equipmentRequired.filter(e => e !== equipment)
                    }));
                  } else {
                    addToArray('equipmentRequired', equipment);
                  }
                }}
              />
              <Label htmlFor={`req-${equipment}`} className="text-sm">{equipment}</Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label>Optional Equipment (Enhances Exercise)</Label>
        <div className="grid grid-cols-3 gap-2 mt-2">
          {equipmentOptions.map((equipment) => (
            <div key={equipment} className="flex items-center space-x-2">
              <Checkbox
                id={`opt-${equipment}`}
                checked={formData.equipmentOptional.includes(equipment)}
                onCheckedChange={() => {
                  if (formData.equipmentOptional.includes(equipment)) {
                    setFormData(prev => ({
                      ...prev,
                      equipmentOptional: prev.equipmentOptional.filter(e => e !== equipment)
                    }));
                  } else {
                    addToArray('equipmentOptional', equipment);
                  }
                }}
              />
              <Label htmlFor={`opt-${equipment}`} className="text-sm">{equipment}</Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderStep7 = () => (
    <div className="space-y-4">
      <Alert>
        <Star className="h-4 w-4" />
        <AlertDescription>
          Define how this exercise fits into a progression system. This helps AI generate better workout sequences.
        </AlertDescription>
      </Alert>
      
      <div>
        <Label htmlFor="primaryVideoUrl">Primary Video URL</Label>
        <Input
          id="primaryVideoUrl"
          type="url"
          value={formData.primaryVideoUrl}
          onChange={(e) => setFormData(prev => ({ ...prev, primaryVideoUrl: e.target.value }))}
          placeholder="https://youtube.com/watch?v=..."
        />
      </div>
    </div>
  );

  const renderStep8 = () => (
    <div className="space-y-4">
      <Card className="bg-gradient-to-r from-orange-50 to-blue-50 dark:from-orange-950/20 dark:to-blue-950/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Exercise Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div>
              <div className="font-medium">{formData.name}</div>
              <div className="text-sm text-muted-foreground">{formData.description}</div>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">{formData.difficultyLevel}</Badge>
              <Badge variant="outline">{formData.durationType}</Badge>
              <Badge variant="outline">Intensity: {formData.intensityLevel}/10</Badge>
            </div>
            
            <div>
              <div className="text-sm font-medium">Instructions:</div>
              <ol className="text-sm text-muted-foreground ml-4 list-decimal">
                {formData.instructions.filter(i => i.trim()).map((instruction, index) => (
                  <li key={index}>{instruction}</li>
                ))}
              </ol>
            </div>

            {formData.equipmentRequired.length > 0 && (
              <div>
                <div className="text-sm font-medium">Required Equipment:</div>
                <div className="flex flex-wrap gap-1 mt-1">
                  {formData.equipmentRequired.map((equipment) => (
                    <Badge key={equipment} variant="secondary" className="text-xs">
                      {equipment}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      case 4: return renderStep4();
      case 5: return renderStep5();
      case 6: return renderStep6();
      case 7: return renderStep7();
      case 8: return renderStep8();
      default: return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6" data-testid="exercise-collection-wizard">
      {renderStepIndicator()}
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {React.createElement(steps[currentStep - 1].icon, { className: "h-5 w-5" })}
            {steps[currentStep - 1].title}
          </CardTitle>
          <CardDescription>
            {steps[currentStep - 1].description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {renderCurrentStep()}
          
          {validationErrors.length > 0 && (
            <Alert className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {validationErrors.map((error, index) => (
                  <div key={index} className={`text-sm ${error.severity === 'error' ? 'text-red-600' : 'text-yellow-600'}`}>
                    {error.message}
                  </div>
                ))}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={onCancel}
          data-testid="button-cancel-wizard"
        >
          Cancel
        </Button>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 1}
          >
            Previous
          </Button>
          
          {currentStep < steps.length ? (
            <Button
              onClick={handleNext}
              disabled={steps[currentStep - 1].required && !canProceedToNextStep()}
              data-testid="button-next-step"
            >
              Next
            </Button>
          ) : (
            <Button
              onClick={handleSave}
              disabled={saveExerciseMutation.isPending}
              className="bg-orange-500 hover:bg-orange-600"
              data-testid="button-save-exercise"
            >
              {saveExerciseMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Exercise
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}