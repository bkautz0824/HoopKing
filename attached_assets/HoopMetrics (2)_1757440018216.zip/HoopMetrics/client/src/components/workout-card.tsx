import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface WorkoutCardProps {
  workout: {
    id: string;
    name: string;
    description?: string;
    duration: number;
    difficulty: string;
    imageUrl?: string;
    categoryId: string;
  };
  onStart: (workoutId: string) => void;
}

export default function WorkoutCard({ workout, onStart }: WorkoutCardProps) {
  const difficultyColors = {
    beginner: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    intermediate: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    advanced: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
  };

  const categoryIcons = {
    'gym': '💪',
    'court': '🏀',
  };

  return (
    <Card 
      className="workout-card overflow-hidden cursor-pointer group"
      onClick={() => onStart(workout.id)}
    >
      <div className="relative">
        {workout.imageUrl ? (
          <div 
            className="h-48 bg-cover bg-center"
            style={{ backgroundImage: `url(${workout.imageUrl})` }}
          />
        ) : (
          <div className="h-48 bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <span className="text-6xl text-primary-foreground opacity-80">
              {categoryIcons[workout.categoryId as keyof typeof categoryIcons] || '🏀'}
            </span>
          </div>
        )}
        <div className="absolute top-4 left-4">
          <Badge 
            className={difficultyColors[workout.difficulty as keyof typeof difficultyColors] || difficultyColors.beginner}
          >
            {workout.difficulty}
          </Badge>
        </div>
        <div className="absolute top-4 right-4">
          <Badge variant="secondary" className="bg-black/20 text-white border-0">
            {workout.duration} min
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
          {workout.name}
        </h3>
        {workout.description && (
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
            {workout.description}
          </p>
        )}
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>⏱️ {workout.duration} min</span>
            <span>•</span>
            <span>🔥 {workout.difficulty}</span>
          </div>
          <Button 
            onClick={(e) => {
              e.stopPropagation();
              onStart(workout.id);
            }}
            size="sm"
            className="bg-primary hover:bg-primary/90"
            data-testid={`button-start-workout-${workout.id}`}
          >
            Start
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
