import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const { user } = useAuth();
  const [location, setLocation] = useLocation();

  const navItems = [
    { path: "/", label: "Home", icon: "🏠", description: "Dashboard & Overview" },
    { path: "/workouts", label: "Workouts", icon: "💪", description: "Browse Training Programs" },
    { path: "/ai-workouts", label: "AI Workouts", icon: "🧠", description: "Personalized Training", badge: "NEW" },
    { path: "/exercises", label: "Exercises", icon: "🏋️", description: "Exercise Library", badge: "PRO" },
    { path: "/progress", label: "Progress", icon: "📊", description: "Analytics & Stats" },
    { path: "/wearables", label: "Wearables", icon: "⌚", description: "Device Integration" },
    { path: "/preferences", label: "Preferences", icon: "⚙️", description: "Settings & Profile" },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border bg-background shadow-sm">
      <div className="w-full">
        <div className="flex h-16 items-center px-4 sm:px-6 lg:px-8">
          {/* Logo */}
          <div className="flex items-center space-x-3 mr-4 flex-shrink-0">
            <button
              onClick={() => setLocation("/")}
              className="flex items-center space-x-2 group"
              data-testid="logo-home"
            >
              <div className="w-9 h-9 bg-primary rounded-lg flex items-center justify-center group-hover:bg-primary/90 transition-all duration-200">
                <span className="text-primary-foreground text-base">🏀</span>
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">CourtFit</span>
                <span className="text-xs text-muted-foreground -mt-0.5">Training</span>
              </div>
            </button>
          </div>
          
          {/* Central Navigation - Desktop with Scrolling */}
          <div className="hidden lg:flex flex-1 items-center justify-center min-w-0 max-w-4xl">
            <div className="relative w-full">
              <div className="flex items-center bg-muted rounded-lg p-1 overflow-x-auto scroll-smooth" style={{scrollbarWidth: 'thin', scrollbarColor: 'hsl(var(--muted-foreground) / 0.3) transparent'}}>
                <div className="flex items-center space-x-1 min-w-max px-2">
                  {navItems.map((item) => {
                    const isActive = location === item.path;
                    return (
                      <button
                        key={item.path}
                        onClick={() => setLocation(item.path)}
                        className={cn(
                          "relative flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 whitespace-nowrap flex-shrink-0",
                          isActive
                            ? "bg-background text-primary shadow-sm border border-primary/20"
                            : "text-muted-foreground hover:text-foreground hover:bg-background/80"
                        )}
                        data-testid={`nav-${item.label.toLowerCase()}`}
                      >
                        <span className="text-sm">{item.icon}</span>
                        <span>{item.label}</span>
                        {item.badge && (
                          <Badge 
                            variant={item.badge === "NEW" ? "default" : "secondary"} 
                            className="text-xs py-0 px-1 h-3"
                          >
                            {item.badge}
                          </Badge>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
              {/* Scroll indicators */}
              <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-muted to-transparent pointer-events-none rounded-l-lg"></div>
              <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-muted to-transparent pointer-events-none rounded-r-lg"></div>
            </div>
          </div>

          {/* Tablet Navigation - Scrollable */}
          <div className="hidden md:flex lg:hidden flex-1 items-center justify-center min-w-0">
            <div className="relative w-full max-w-2xl">
              <div className="flex items-center bg-muted rounded-lg p-1 overflow-x-auto scroll-smooth" style={{scrollbarWidth: 'thin', scrollbarColor: 'hsl(var(--muted-foreground) / 0.3) transparent'}}>
                <div className="flex items-center space-x-1 min-w-max px-1">
                  {navItems.map((item) => {
                    const isActive = location === item.path;
                    return (
                      <button
                        key={item.path}
                        onClick={() => setLocation(item.path)}
                        className={cn(
                          "flex flex-col items-center space-y-1 p-2 rounded-md text-xs font-medium transition-all duration-200 min-w-[3.5rem] flex-shrink-0",
                          isActive
                            ? "text-primary bg-background border border-primary/20"
                            : "text-muted-foreground hover:text-foreground hover:bg-background/80"
                        )}
                        data-testid={`nav-${item.label.toLowerCase()}`}
                        title={item.description}
                      >
                        <span className="text-base">{item.icon}</span>
                        <span className="truncate text-xs">{item.label}</span>
                        {item.badge && (
                          <Badge variant="secondary" className="text-xs py-0 px-1 h-3 absolute -top-1 -right-1">
                            {item.badge}
                          </Badge>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="absolute left-0 top-0 bottom-0 w-6 bg-gradient-to-r from-muted to-transparent pointer-events-none rounded-l-lg"></div>
              <div className="absolute right-0 top-0 bottom-0 w-6 bg-gradient-to-l from-muted to-transparent pointer-events-none rounded-r-lg"></div>
            </div>
          </div>
          
          {/* User Profile & Actions */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              {(user as any)?.profileImageUrl ? (
                <img 
                  src={(user as any).profileImageUrl} 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full object-cover border border-border"
                />
              ) : (
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-semibold">
                  {(user as any)?.firstName?.charAt(0) || (user as any)?.email?.charAt(0)?.toUpperCase() || 'U'}
                </div>
              )}
              <div className="hidden sm:block">
                <p className="text-sm font-medium text-foreground">
                  {(user as any)?.firstName || 'User'}
                </p>
                <p className="text-xs text-muted-foreground">
                  Athlete
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.location.href = '/api/logout'}
              className="text-xs px-3 py-2 h-8"
              data-testid="button-logout"
            >
              Sign Out
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation Bottom - Scrollable */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border">
          <div className="overflow-x-auto scrollbar-hide">
            <div className="flex items-center px-2 py-2 min-w-max">
              {navItems.map((item) => {
                const isActive = location === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => setLocation(item.path)}
                    className={cn(
                      "flex flex-col items-center py-2 px-3 text-xs font-medium transition-all duration-200 rounded-lg min-w-[4rem] relative",
                      isActive
                        ? "text-primary bg-primary/10"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                    data-testid={`mobile-nav-${item.label.toLowerCase()}`}
                  >
                    <span className="text-lg mb-1">{item.icon}</span>
                    <span className="truncate leading-none">{item.label}</span>
                    {item.badge && (
                      <Badge 
                        variant="secondary" 
                        className="text-xs py-0 px-1 h-3 absolute -top-1 -right-1"
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
