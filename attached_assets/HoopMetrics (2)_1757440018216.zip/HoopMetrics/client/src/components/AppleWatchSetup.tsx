import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { CheckCircle, AlertCircle, Heart, Activity, Watch, Zap } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface AppleWatchSetupProps {
  onConnectionSuccess: (deviceData: any) => void;
  onClose: () => void;
}

export function AppleWatchSetup({ onConnectionSuccess, onClose }: AppleWatchSetupProps) {
  const [connectionState, setConnectionState] = useState<'idle' | 'connecting' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string>('');
  const [permissions, setPermissions] = useState({
    heartRate: false,
    calories: false,
    workouts: false,
    hrv: false
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const requestedPermissions = [
    { key: 'heartRate' as const, label: 'Heart Rate', icon: Heart, description: 'Real-time heart rate during workouts' },
    { key: 'calories' as const, label: 'Calories', icon: Activity, description: 'Active and total calories burned' },
    { key: 'workouts' as const, label: 'Workouts', icon: Watch, description: 'Workout detection and metrics' },
    { key: 'hrv' as const, label: 'HRV & Recovery', icon: Zap, description: 'Heart rate variability for recovery tracking' }
  ];

  const connectMutation = useMutation({
    mutationFn: async () => {
      // Step 1: Check compatibility
      const compatibilityResponse = await apiRequest('/api/wearables/apple-watch/compatibility');
      if (!compatibilityResponse.compatible) {
        throw new Error('Apple Watch integration not available on this device');
      }

      // Step 2: Request permissions
      const authResponse = await apiRequest('/api/wearables/apple-watch/auth', 'POST', {
        permissions: requestedPermissions.map(p => p.key)
      });

      // Step 3: Test connection
      const testResponse = await apiRequest('/api/wearables/apple-watch/test', 'POST', {
        token: authResponse.token
      });

      return { ...authResponse, testData: testResponse };
    },
    onMutate: () => {
      setConnectionState('connecting');
      setError('');
    },
    onSuccess: (data) => {
      // Update permissions based on actual test results
      if (data.testData?.data) {
        setPermissions({
          heartRate: data.testData.data.heartRatePermission,
          calories: data.testData.data.caloriesPermission,
          workouts: data.testData.data.workoutsPermission,
          hrv: data.testData.data.hrvPermission
        });
      }
      
      setConnectionState('success');
      
      // Invalidate devices query to refresh UI
      queryClient.invalidateQueries({ queryKey: ['/api/wearables/devices'] });
      
      toast({
        title: "Apple Watch Connected!",
        description: "Your Apple Watch is now connected and ready for workouts.",
      });

      // Call success callback
      onConnectionSuccess(data.deviceData);
    },
    onError: (error: any) => {
      const errorMessage = error.message || 'Failed to connect Apple Watch';
      setError(errorMessage);
      setConnectionState('error');
      
      toast({
        title: "Connection Failed",
        description: errorMessage,
        variant: "destructive",
      });
    }
  });

  const handleConnect = () => {
    connectMutation.mutate();
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          <div className="p-4 bg-primary/10 rounded-full">
            <Watch className="h-8 w-8 text-primary" />
          </div>
        </div>
        <CardTitle className="text-xl">Connect Apple Watch</CardTitle>
        <p className="text-muted-foreground text-sm">
          Enhance your workouts with real-time biometric data
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {connectionState === 'idle' && (
          <>
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-foreground">Health Data Access</h3>
              <div className="grid gap-3">
                {requestedPermissions.map((permission) => {
                  const Icon = permission.icon;
                  return (
                    <div key={permission.key} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                      <Icon className="h-5 w-5 text-muted-foreground" />
                      <div className="flex-1">
                        <div className="text-sm font-medium text-foreground">{permission.label}</div>
                        <div className="text-xs text-muted-foreground">{permission.description}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <Alert>
              <Heart className="h-4 w-4" />
              <AlertDescription className="text-xs">
                CourtFit will request access to your health data to provide personalized workout recommendations and real-time coaching.
              </AlertDescription>
            </Alert>

            <div className="flex gap-2">
              <Button 
                onClick={handleConnect} 
                className="flex-1"
                data-testid="button-connect-apple-watch"
              >
                Connect Apple Watch
              </Button>
              <Button variant="outline" onClick={onClose} data-testid="button-cancel-connection">
                Cancel
              </Button>
            </div>
          </>
        )}

        {connectionState === 'connecting' && (
          <div className="text-center py-8">
            <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <div className="text-sm text-foreground font-medium">Connecting to Apple Watch...</div>
            <div className="text-xs text-muted-foreground mt-1">
              Please approve permissions on your iPhone
            </div>
          </div>
        )}

        {connectionState === 'success' && (
          <div className="text-center py-4">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <div className="text-sm font-medium text-foreground mb-4">Apple Watch Connected!</div>
            
            <div className="space-y-2 mb-6">
              <h3 className="text-xs font-medium text-muted-foreground">PERMISSIONS GRANTED</h3>
              <div className="grid gap-2">
                {requestedPermissions.map((permission) => {
                  const granted = permissions[permission.key];
                  const Icon = permission.icon;
                  return (
                    <div key={permission.key} className="flex items-center gap-2 text-xs">
                      <Icon className="h-3 w-3" />
                      <span className="flex-1 text-left">{permission.label}</span>
                      <Badge variant={granted ? "default" : "secondary"} className="text-xs">
                        {granted ? "Granted" : "Denied"}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </div>

            <Button onClick={onClose} className="w-full" data-testid="button-finish-setup">
              Finish Setup
            </Button>
          </div>
        )}

        {connectionState === 'error' && (
          <div className="text-center py-4">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <div className="text-sm font-medium text-foreground mb-2">Connection Failed</div>
            <div className="text-xs text-muted-foreground mb-6">{error}</div>
            
            <div className="flex gap-2">
              <Button 
                onClick={handleConnect} 
                variant="outline" 
                className="flex-1"
                data-testid="button-retry-connection"
              >
                Try Again
              </Button>
              <Button onClick={onClose} className="flex-1" data-testid="button-close-error">
                Close
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}