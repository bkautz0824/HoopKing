import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

interface ProgressChartProps {
  data: Array<{
    date: string;
    workouts: number;
    duration: number;
  }>;
}

export default function ProgressChart({ data }: ProgressChartProps) {
  // Process data for last 7 days
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date.toISOString().split('T')[0];
  });

  const chartData = last7Days.map(date => {
    const dayData = data.find(d => d.date === date);
    const dayName = new Date(date).toLocaleDateString('en-US', { weekday: 'short' });
    
    return {
      day: dayName,
      date: date,
      workouts: dayData?.workouts || 0,
      duration: dayData?.duration || 0,
    };
  });

  const maxWorkouts = Math.max(...chartData.map(d => d.workouts), 1);
  const maxDuration = Math.max(...chartData.map(d => d.duration), 1);

  if (data.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-6xl mb-4">📈</div>
        <h3 className="text-xl font-semibold text-foreground mb-2">No progress data yet</h3>
        <p className="text-muted-foreground">
          Complete workouts to see your progress over time
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Workout Frequency Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Daily Workouts (Last 7 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="day" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  domain={[0, maxWorkouts + 1]}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    color: 'hsl(var(--foreground))'
                  }}
                  formatter={(value, name) => [
                    `${value} ${name === 'workouts' ? 'workouts' : 'minutes'}`,
                    name === 'workouts' ? 'Workouts' : 'Duration'
                  ]}
                  labelFormatter={(label) => `${label}`}
                />
                <Bar 
                  dataKey="workouts" 
                  fill="hsl(var(--primary))"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Duration Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Training Duration (Last 7 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="day" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  domain={[0, maxDuration + 10]}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    color: 'hsl(var(--foreground))'
                  }}
                  formatter={(value) => [`${value} minutes`, 'Duration']}
                  labelFormatter={(label) => `${label}`}
                />
                <Line 
                  type="monotone" 
                  dataKey="duration" 
                  stroke="hsl(var(--secondary))"
                  strokeWidth={3}
                  dot={{ fill: 'hsl(var(--secondary))', strokeWidth: 2, r: 6 }}
                  activeDot={{ r: 8, fill: 'hsl(var(--secondary))' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">
              {chartData.reduce((sum, day) => sum + day.workouts, 0)}
            </div>
            <p className="text-sm text-muted-foreground">Total workouts</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-secondary">
              {chartData.reduce((sum, day) => sum + day.duration, 0)}m
            </div>
            <p className="text-sm text-muted-foreground">Total time</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-foreground">
              {Math.round(chartData.reduce((sum, day) => sum + day.duration, 0) / Math.max(chartData.filter(d => d.workouts > 0).length, 1))}m
            </div>
            <p className="text-sm text-muted-foreground">Avg duration</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-foreground">
              {chartData.filter(d => d.workouts > 0).length}
            </div>
            <p className="text-sm text-muted-foreground">Active days</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
