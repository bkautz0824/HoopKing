import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface StatsOverviewProps {
  userStats?: {
    workoutsCompleted?: number;
    totalWorkoutTime?: number;
    currentStreak?: number;
    shotsAttempted?: number;
    shotsMade?: number;
  };
}

export default function StatsOverview({ userStats }: StatsOverviewProps) {
  const stats = [
    {
      title: "Workouts This Week",
      value: userStats?.workoutsCompleted || 0,
      change: "+2 from last week",
      trend: "up" as const,
      icon: "💪",
      color: "primary",
    },
    {
      title: "Total Hours",
      value: Math.round((userStats?.totalWorkoutTime || 0) / 60),
      change: "+5.2 hours this month", 
      trend: "up" as const,
      icon: "⏱️",
      color: "secondary",
    },
    {
      title: "Current Streak",
      value: `${userStats?.currentStreak || 0} days`,
      change: userStats?.currentStreak ? "Keep it going!" : "Start your streak",
      trend: userStats?.currentStreak ? "up" as const : "neutral" as const,
      icon: "🔥",
      color: "primary",
    },
    {
      title: "Shot Accuracy",
      value: userStats?.shotsAttempted && userStats?.shotsMade 
        ? `${Math.round((userStats.shotsMade / userStats.shotsAttempted) * 100)}%`
        : "0%",
      change: "Track your shots",
      trend: "neutral" as const,
      icon: "🎯",
      color: "secondary",
    },
  ];

  const trendColors = {
    up: 'text-green-600 dark:text-green-400',
    down: 'text-red-600 dark:text-red-400',
    neutral: 'text-muted-foreground'
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <Card key={stat.title} className="animate-fade-in bg-card border border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {stat.title}
            </CardTitle>
            <div className="text-2xl">
              {stat.icon}
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {stat.value}
            </div>
            <div className={`text-xs flex items-center mt-1 ${trendColors[stat.trend]}`}>
              {stat.trend === 'up' && <span className="mr-1">↗️</span>}
              {stat.trend === 'down' && <span className="mr-1">↘️</span>}
              {stat.change}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
