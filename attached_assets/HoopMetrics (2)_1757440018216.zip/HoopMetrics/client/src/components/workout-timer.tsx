import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface WorkoutTimerProps {
  duration: number; // in seconds
  onComplete: () => void;
  autoStart?: boolean;
}

export default function WorkoutTimer({ duration, onComplete, autoStart = false }: WorkoutTimerProps) {
  const [timeLeft, setTimeLeft] = useState(duration);
  const [isActive, setIsActive] = useState(autoStart);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isActive && !isPaused && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => {
          if (time <= 1) {
            setIsActive(false);
            onComplete();
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, isPaused, timeLeft, onComplete]);

  const handleStart = () => {
    setIsActive(true);
    setIsPaused(false);
  };

  const handlePause = () => {
    setIsPaused(true);
  };

  const handleResume = () => {
    setIsPaused(false);
  };

  const handleReset = () => {
    setTimeLeft(duration);
    setIsActive(false);
    setIsPaused(false);
  };

  const handleSkip = () => {
    setIsActive(false);
    setTimeLeft(0);
    onComplete();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = duration > 0 ? ((duration - timeLeft) / duration) * 100 : 0;
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <Card className="text-center">
      <CardContent className="p-6 space-y-6">
        {/* Timer Display */}
        <div className="relative w-32 h-32 mx-auto">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle 
              cx="50" cy="50" r="45" 
              stroke="hsl(var(--muted))" 
              strokeWidth="6" 
              fill="transparent" 
            />
            <circle 
              cx="50" cy="50" r="45" 
              stroke="hsl(var(--primary))" 
              strokeWidth="6" 
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="progress-ring transition-all duration-300" 
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <span className="text-2xl font-bold text-foreground">
                {formatTime(timeLeft)}
              </span>
            </div>
          </div>
        </div>

        {/* Status */}
        <div>
          {timeLeft === 0 ? (
            <div className="text-primary font-semibold">
              ✅ Exercise Complete!
            </div>
          ) : isActive && !isPaused ? (
            <div className="text-primary font-semibold pulse-animation">
              🔥 Training in Progress
            </div>
          ) : isPaused ? (
            <div className="text-secondary font-semibold">
              ⏸️ Paused
            </div>
          ) : (
            <div className="text-muted-foreground">
              Ready to start
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex justify-center space-x-3">
          {!isActive && timeLeft > 0 && (
            <Button 
              onClick={handleStart}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-timer-start"
            >
              ▶️ Start
            </Button>
          )}
          
          {isActive && !isPaused && (
            <Button 
              onClick={handlePause}
              variant="outline"
              data-testid="button-timer-pause"
            >
              ⏸️ Pause
            </Button>
          )}
          
          {isPaused && (
            <Button 
              onClick={handleResume}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-timer-resume"
            >
              ▶️ Resume
            </Button>
          )}
          
          {(isActive || isPaused) && (
            <Button 
              onClick={handleReset}
              variant="destructive"
              data-testid="button-timer-reset"
            >
              🔄 Reset
            </Button>
          )}
          
          {timeLeft > 0 && (
            <Button 
              onClick={handleSkip}
              variant="outline"
              data-testid="button-timer-skip"
            >
              ⏭️ Skip
            </Button>
          )}
        </div>

        {/* Progress Info */}
        <div className="text-sm text-muted-foreground">
          {timeLeft > 0 ? (
            <p>
              {Math.round(progress)}% complete • {timeLeft}s remaining
            </p>
          ) : (
            <p>Exercise completed successfully!</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
