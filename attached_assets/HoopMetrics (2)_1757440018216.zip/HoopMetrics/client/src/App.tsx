import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/navigation";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Workouts from "@/pages/workouts";
import WorkoutDetail from "@/pages/workout-detail";
import ActiveWorkout from "@/pages/active-workout";
import Progress from "@/pages/progress";
import Wearables from "@/pages/wearables";
import Preferences from "@/pages/preferences";
import AIWorkouts from "@/pages/ai-workouts";
import AIWorkoutDetail from "@/pages/ai-workout-detail";
import AIWorkoutActive from "@/pages/ai-workout-active";
import ExerciseManagement from "@/pages/exercise-management";

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pb-20 md:pb-6">
        {children}
      </main>
    </div>
  );
}

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/">
            {() => (
              <AppLayout>
                <Home />
              </AppLayout>
            )}
          </Route>
          <Route path="/workouts">
            {() => (
              <AppLayout>
                <Workouts />
              </AppLayout>
            )}
          </Route>
          <Route path="/workouts/:id">
            {(params) => (
              <AppLayout>
                <WorkoutDetail params={params} />
              </AppLayout>
            )}
          </Route>
          <Route path="/workout/:id/active">
            {(params) => (
              <AppLayout>
                <ActiveWorkout params={params} />
              </AppLayout>
            )}
          </Route>
          <Route path="/progress">
            {() => (
              <AppLayout>
                <Progress />
              </AppLayout>
            )}
          </Route>
          <Route path="/wearables">
            {() => (
              <AppLayout>
                <Wearables />
              </AppLayout>
            )}
          </Route>
          <Route path="/preferences">
            {() => (
              <AppLayout>
                <Preferences />
              </AppLayout>
            )}
          </Route>
          <Route path="/ai-workouts">
            {() => (
              <AppLayout>
                <AIWorkouts />
              </AppLayout>
            )}
          </Route>
          <Route path="/ai-workouts/:id">
            {(params) => (
              <AppLayout>
                <AIWorkoutDetail params={params} />
              </AppLayout>
            )}
          </Route>
          <Route path="/ai-workouts/:id/active">
            {(params) => (
              <AppLayout>
                <AIWorkoutActive params={params} />
              </AppLayout>
            )}
          </Route>
          <Route path="/exercises">
            {() => (
              <AppLayout>
                <ExerciseManagement />
              </AppLayout>
            )}
          </Route>
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
