import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Watch, Smartphone, Activity, Heart, Zap, Trash2, Plus, CheckCircle, Wifi } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { AppleWatchSetup } from "@/components/AppleWatchSetup";

type WearableDevice = {
  id: string;
  deviceType: string;
  deviceModel: string;
  deviceId: string;
  isActive: boolean;
  lastSync: string;
  createdAt: string;
};

type WearableData = {
  id: string;
  heartRateData: any;
  caloriesBurned: number;
  steps: number;
  distance: number;
  vo2Max: number;
  effortScore: number;
  recordedAt: string;
};

const deviceTypeOptions = [
  { value: "apple_watch", label: "Apple Watch", icon: Watch },
  { value: "garmin", label: "Garmin", icon: Smartphone },
  { value: "coros", label: "Coros", icon: Activity },
  { value: "fitbit", label: "Fitbit", icon: Heart },
  { value: "samsung", label: "Samsung Galaxy Watch", icon: Watch },
];

export default function WearablesPage() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddingDevice, setIsAddingDevice] = useState(false);
  const [showAppleWatchSetup, setShowAppleWatchSetup] = useState(false);
  
  const [newDevice, setNewDevice] = useState({
    deviceType: "",
    deviceModel: "",
    deviceId: "",
  });

  // Fetch user's connected devices
  const { data: devices = [], isLoading } = useQuery<WearableDevice[]>({
    queryKey: ["/api/wearables/devices"],
    enabled: !!user,
  });

  // Fetch recent wearable data
  const { data: recentData = [] } = useQuery<WearableData[]>({
    queryKey: ["/api/wearables/data/recent"],
    enabled: !!user,
  });

  // Fetch recovery data for Apple Watch users
  const { data: recoveryData } = useQuery<{recoveryScore: number | null, hrv: number | null, restingHeartRate: number | null}>({
    queryKey: ["/api/wearables/apple-watch/recovery"],
    enabled: !!user && devices.some((device: WearableDevice) => device.deviceType === 'apple_watch' && device.isActive),
  });

  // Add device mutation
  const addDeviceMutation = useMutation({
    mutationFn: async (device: typeof newDevice) => {
      await apiRequest("POST", "/api/wearables/devices", device);
    },
    onSuccess: () => {
      toast({
        title: "Device Connected!",
        description: "Your wearable device has been successfully connected.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wearables/devices"] });
      setIsAddingDevice(false);
      setNewDevice({ deviceType: "", deviceModel: "", deviceId: "" });
    },
    onError: (error) => {
      toast({
        title: "Connection Failed",
        description: "Failed to connect your device. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Remove device mutation
  const removeDeviceMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      await apiRequest("DELETE", `/api/wearables/devices/${deviceId}`);
    },
    onSuccess: () => {
      toast({
        title: "Device Disconnected",
        description: "Your wearable device has been disconnected.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wearables/devices"] });
    },
  });

  // Sync data mutation
  const syncDataMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      await apiRequest("POST", `/api/wearables/sync/${deviceId}`);
    },
    onSuccess: () => {
      toast({
        title: "Data Synced!",
        description: "Your latest workout data has been synchronized.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wearables/data/recent"] });
    },
  });

  const handleAddDevice = () => {
    // Special handling for Apple Watch - use dedicated setup flow
    if (newDevice.deviceType === 'apple_watch') {
      setIsAddingDevice(false);
      setShowAppleWatchSetup(true);
      return;
    }
    
    if (!newDevice.deviceType || !newDevice.deviceModel || !newDevice.deviceId) {
      toast({
        title: "Missing Information",
        description: "Please fill in all device details.",
        variant: "destructive",
      });
      return;
    }
    addDeviceMutation.mutate(newDevice);
  };

  const handleAppleWatchSuccess = (deviceData: any) => {
    setShowAppleWatchSetup(false);
    queryClient.invalidateQueries({ queryKey: ["/api/wearables/devices"] });
  };

  const getDeviceIcon = (type: string) => {
    const device = deviceTypeOptions.find(d => d.value === type);
    return device ? device.icon : Watch;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  if (authLoading || isLoading) {
    return (
      <div className="container mx-auto p-6 flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your devices...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl" data-testid="wearables-page">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Wearable Devices</h1>
            <p className="text-muted-foreground mt-2">
              Connect your fitness devices to track advanced metrics during workouts
            </p>
          </div>
        </div>

        {/* Recovery Metrics */}
        {recoveryData && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Today's Recovery Status
              </CardTitle>
              <CardDescription>
                Your recovery metrics from connected Apple Watch
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold text-foreground">
                    {recoveryData.recoveryScore || '--'}
                  </div>
                  <div className="text-sm text-muted-foreground">Recovery Score</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Overall readiness for training
                  </div>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold text-foreground">
                    {recoveryData.hrv ? `${Math.round(recoveryData.hrv)}ms` : '--'}
                  </div>
                  <div className="text-sm text-muted-foreground">HRV</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Heart rate variability
                  </div>
                </div>
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold text-foreground">
                    {recoveryData.restingHeartRate ? `${recoveryData.restingHeartRate} bpm` : '--'}
                  </div>
                  <div className="text-sm text-muted-foreground">Resting HR</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Baseline heart rate
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Add Device Section */}
        <div className="flex justify-end">
          <Dialog open={isAddingDevice} onOpenChange={setIsAddingDevice}>
            <DialogTrigger asChild>
              <Button className="bg-orange-500 hover:bg-orange-600" data-testid="button-add-device">
                <Plus className="h-4 w-4 mr-2" />
                Add Device
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Connect Wearable Device</DialogTitle>
                <DialogDescription>
                  Add your fitness device to start tracking advanced metrics
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="deviceType">Device Type</Label>
                  <Select 
                    value={newDevice.deviceType} 
                    onValueChange={(value) => setNewDevice({...newDevice, deviceType: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose your device type" />
                    </SelectTrigger>
                    <SelectContent>
                      {deviceTypeOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            <option.icon className="h-4 w-4" />
                            {option.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="deviceModel">Device Model</Label>
                  <Input
                    id="deviceModel"
                    value={newDevice.deviceModel}
                    onChange={(e) => setNewDevice({...newDevice, deviceModel: e.target.value})}
                    placeholder="e.g., Series 9, Forerunner 955, PACE 3"
                  />
                </div>

                <div>
                  <Label htmlFor="deviceId">Device ID/Serial</Label>
                  <Input
                    id="deviceId"
                    value={newDevice.deviceId}
                    onChange={(e) => setNewDevice({...newDevice, deviceId: e.target.value})}
                    placeholder="Enter device serial or ID"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button 
                    onClick={handleAddDevice}
                    disabled={addDeviceMutation.isPending}
                    className="flex-1"
                    data-testid="button-connect-device"
                  >
                    {addDeviceMutation.isPending ? "Connecting..." : "Connect Device"}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setIsAddingDevice(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Connected Devices */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Watch className="h-5 w-5" />
              Connected Devices
            </CardTitle>
            <CardDescription>
              Manage your connected fitness devices and sync data
            </CardDescription>
          </CardHeader>
          <CardContent>
            {devices.length === 0 ? (
              <div className="text-center py-8">
                <Watch className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Devices Connected</h3>
                <p className="text-muted-foreground mb-4">
                  Connect your first wearable device to start tracking advanced metrics
                </p>
                <Button 
                  onClick={() => setIsAddingDevice(true)}
                  data-testid="button-connect-first-device"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Connect Device
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {devices.map((device: WearableDevice) => {
                  const DeviceIcon = getDeviceIcon(device.deviceType);
                  return (
                    <div 
                      key={device.id} 
                      className="flex items-center justify-between p-4 border rounded-lg"
                      data-testid={`device-${device.deviceType}`}
                    >
                      <div className="flex items-center gap-3">
                        <DeviceIcon className="h-6 w-6 text-orange-500" />
                        <div>
                          <h4 className="font-medium">{device.deviceModel}</h4>
                          <p className="text-sm text-muted-foreground">
                            {deviceTypeOptions.find(d => d.value === device.deviceType)?.label}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Last sync: {device.lastSync ? formatDate(device.lastSync) : 'Never'}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge variant={device.isActive ? "default" : "secondary"}>
                          {device.isActive ? (
                            <><CheckCircle className="h-3 w-3 mr-1" /> Active</>
                          ) : (
                            "Inactive"
                          )}
                        </Badge>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => syncDataMutation.mutate(device.id)}
                          disabled={syncDataMutation.isPending}
                          data-testid={`button-sync-${device.deviceType}`}
                        >
                          <Zap className="h-4 w-4 mr-1" />
                          Sync
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => removeDeviceMutation.mutate(device.id)}
                          disabled={removeDeviceMutation.isPending}
                          data-testid={`button-remove-${device.deviceType}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Data */}
        {recentData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Recent Sync Data
              </CardTitle>
              <CardDescription>
                Latest metrics from your connected devices
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {recentData.slice(0, 6).map((data: WearableData) => (
                  <Card key={data.id} className="p-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Calories</span>
                        <span className="font-medium">{data.caloriesBurned}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Steps</span>
                        <span className="font-medium">{data.steps}</span>
                      </div>
                      {data.effortScore && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Effort Score</span>
                          <Badge variant="outline">{data.effortScore}/10</Badge>
                        </div>
                      )}
                      <Separator />
                      <p className="text-xs text-muted-foreground">
                        {formatDate(data.recordedAt)}
                      </p>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Information Cards */}
        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Supported Devices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {deviceTypeOptions.map((option) => (
                  <div key={option.value} className="flex items-center gap-3">
                    <option.icon className="h-5 w-5 text-orange-500" />
                    <span>{option.label}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Tracked Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div>• Heart rate zones and variability</div>
                <div>• Calories burned (active & total)</div>
                <div>• Steps and distance covered</div>
                <div>• VO2 Max and recovery metrics</div>
                <div>• Basketball-specific effort scoring</div>
                <div>• Workout intensity distribution</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Apple Watch Setup Dialog */}
        <Dialog open={showAppleWatchSetup} onOpenChange={setShowAppleWatchSetup}>
          <DialogContent className="max-w-md">
            <AppleWatchSetup
              onConnectionSuccess={handleAppleWatchSuccess}
              onClose={() => setShowAppleWatchSetup(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}