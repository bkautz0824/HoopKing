import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import WorkoutTimer from "@/components/workout-timer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface ActiveWorkoutProps {
  params: {
    id: string;
  };
}

export default function ActiveWorkout({ params }: ActiveWorkoutProps) {
  const [, setLocation] = useLocation();
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [currentSet, setCurrentSet] = useState(1);
  const [repsCompleted, setRepsCompleted] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [restTimeLeft, setRestTimeLeft] = useState(0);
  const workoutId = params.id;

  const { data: workout } = useQuery({
    queryKey: [`/api/workouts/${workoutId}`],
    enabled: !!workoutId,
  });

  const { data: activeSession } = useQuery({
    queryKey: ["/api/sessions/active"],
  });

  const completeExerciseMutation = useMutation({
    mutationFn: async (performanceData: any) => {
      const response = await apiRequest('POST', '/api/performance', performanceData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
    },
  });

  const completeWorkoutMutation = useMutation({
    mutationFn: async () => {
      if (!activeSession) return;
      const response = await apiRequest('PATCH', `/api/sessions/${activeSession.id}`, {
        status: 'completed',
        completedAt: new Date().toISOString(),
        totalDuration: Math.floor((Date.now() - new Date(activeSession.startedAt).getTime()) / 60000),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      setLocation('/');
    },
  });

  const currentExercise = workout?.exercises?.[currentExerciseIndex];
  const totalExercises = workout?.exercises?.length || 0;
  const progress = totalExercises > 0 ? ((currentExerciseIndex + 1) / totalExercises) * 100 : 0;

  // Rest timer effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isResting && restTimeLeft > 0) {
      timer = setTimeout(() => {
        setRestTimeLeft(restTimeLeft - 1);
      }, 1000);
    } else if (isResting && restTimeLeft === 0) {
      setIsResting(false);
    }
    return () => clearTimeout(timer);
  }, [isResting, restTimeLeft]);

  const handleCompleteSet = () => {
    if (!currentExercise || !activeSession) return;

    // Record performance
    completeExerciseMutation.mutate({
      sessionId: activeSession.id,
      exerciseId: currentExercise.id,
      setsCompleted: currentSet,
      repsCompleted: repsCompleted,
      completed: currentSet === (currentExercise.sets || 1),
    });

    if (currentSet < (currentExercise.sets || 1)) {
      // More sets to go, start rest period
      setCurrentSet(currentSet + 1);
      setRepsCompleted(0);
      if (currentExercise.restTime) {
        setIsResting(true);
        setRestTimeLeft(currentExercise.restTime);
      }
    } else {
      // Exercise complete, move to next
      handleNextExercise();
    }
  };

  const handleNextExercise = () => {
    if (currentExerciseIndex < totalExercises - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
      setCurrentSet(1);
      setRepsCompleted(0);
      setIsResting(false);
      setRestTimeLeft(0);
    } else {
      // Workout complete
      completeWorkoutMutation.mutate();
    }
  };

  const handleSkipRest = () => {
    setIsResting(false);
    setRestTimeLeft(0);
  };

  if (!workout) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-3/4"></div>
            <div className="h-64 bg-muted rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  if (isResting) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Card className="text-center">
            <CardContent className="p-12">
              <div className="text-6xl mb-6">😴</div>
              <h2 className="text-3xl font-bold text-foreground mb-4">Rest Time</h2>
              <div className="text-6xl font-bold text-primary mb-6">
                {Math.floor(restTimeLeft / 60)}:{(restTimeLeft % 60).toString().padStart(2, '0')}
              </div>
              <p className="text-muted-foreground mb-8">
                Get ready for set {currentSet} of {currentExercise?.name}
              </p>
              <div className="space-x-4">
                <Button onClick={handleSkipRest} variant="outline">
                  Skip Rest
                </Button>
                <Button onClick={() => setLocation('/')} variant="destructive">
                  End Workout
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-2xl font-bold text-foreground">{workout.name}</h1>
                <p className="text-muted-foreground">
                  Exercise {currentExerciseIndex + 1} of {totalExercises}
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => setLocation('/')}
                data-testid="button-end-workout"
              >
                End Workout
              </Button>
            </div>
            <Progress value={progress} className="h-2" />
          </CardContent>
        </Card>

        {/* Current Exercise */}
        {currentExercise && (
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">{currentExercise.name}</CardTitle>
                <div className="flex space-x-2">
                  <Badge variant="outline">
                    Set {currentSet} of {currentExercise.sets || 1}
                  </Badge>
                  {currentExercise.reps && (
                    <Badge variant="secondary">
                      {currentExercise.reps} reps
                    </Badge>
                  )}
                  {currentExercise.duration && (
                    <Badge variant="secondary">
                      {currentExercise.duration}s
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {currentExercise.description && (
                <p className="text-muted-foreground">{currentExercise.description}</p>
              )}

              {currentExercise.instructions && (
                <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Instructions:</h4>
                  <p className="text-sm text-blue-800 dark:text-blue-200">
                    {currentExercise.instructions}
                  </p>
                </div>
              )}

              {currentExercise.tips && (
                <div className="p-4 bg-amber-50 dark:bg-amber-950 rounded-lg">
                  <h4 className="font-medium text-amber-900 dark:text-amber-100 mb-2">💡 Tips:</h4>
                  <p className="text-sm text-amber-800 dark:text-amber-200">
                    {currentExercise.tips}
                  </p>
                </div>
              )}

              {/* Rep Counter */}
              {currentExercise.reps && (
                <div className="text-center space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">Reps Completed</h3>
                    <div className="flex items-center justify-center space-x-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setRepsCompleted(Math.max(0, repsCompleted - 1))}
                        data-testid="button-decrement-reps"
                      >
                        -
                      </Button>
                      <span className="text-3xl font-bold text-foreground w-16 text-center">
                        {repsCompleted}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setRepsCompleted(repsCompleted + 1)}
                        data-testid="button-increment-reps"
                      >
                        +
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      Target: {currentExercise.reps} reps
                    </p>
                  </div>
                </div>
              )}

              {/* Timer for timed exercises */}
              {currentExercise.duration && (
                <WorkoutTimer 
                  duration={currentExercise.duration}
                  onComplete={handleCompleteSet}
                />
              )}
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex space-x-4">
          <Button
            onClick={handleCompleteSet}
            disabled={completeExerciseMutation.isPending}
            className="flex-1 bg-primary hover:bg-primary/90"
            data-testid="button-complete-set"
          >
            {completeExerciseMutation.isPending ? (
              <>
                <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2"></div>
                Recording...
              </>
            ) : currentSet < (currentExercise?.sets || 1) ? (
              'Complete Set'
            ) : currentExerciseIndex < totalExercises - 1 ? (
              'Next Exercise'
            ) : (
              'Complete Workout'
            )}
          </Button>
          
          {currentExerciseIndex > 0 && (
            <Button
              variant="outline"
              onClick={() => {
                setCurrentExerciseIndex(currentExerciseIndex - 1);
                setCurrentSet(1);
                setRepsCompleted(0);
              }}
              data-testid="button-previous-exercise"
            >
              Previous
            </Button>
          )}
        </div>
      </main>
    </div>
  );
}
