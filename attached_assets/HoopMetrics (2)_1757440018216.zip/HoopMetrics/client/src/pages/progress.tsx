import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import ProgressChart from "@/components/progress-chart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Progress() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: userStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
    enabled: isAuthenticated,
  });

  const { data: shootingStats, isLoading: shootingLoading } = useQuery({
    queryKey: ["/api/stats/shooting"],
    enabled: isAuthenticated,
  });

  const { data: weeklyProgress, isLoading: progressLoading } = useQuery({
    queryKey: ["/api/progress/weekly"],
    enabled: isAuthenticated,
  });

  const { data: userAchievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["/api/achievements/user"],
    enabled: isAuthenticated,
  });

  const { data: recentSessions, isLoading: sessionsLoading } = useQuery({
    queryKey: ["/api/sessions/recent"],
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            Your Progress 📊
          </h1>
          <p className="text-muted-foreground text-lg">
            Track your improvement and celebrate your achievements
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="shooting" data-testid="tab-shooting">Shooting</TabsTrigger>
            <TabsTrigger value="workouts" data-testid="tab-workouts">Workouts</TabsTrigger>
            <TabsTrigger value="achievements" data-testid="tab-achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Overall Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="stat-card text-primary-foreground">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-primary-foreground/80">
                    Total Workouts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {userStats?.workoutsCompleted || 0}
                  </div>
                  <p className="text-sm text-primary-foreground/80 mt-1">
                    All time completed
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Training Hours
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-foreground">
                    {Math.round((userStats?.totalWorkoutTime || 0) / 60)}h
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Time invested
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Current Streak
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-foreground">
                    {userStats?.currentStreak || 0}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Days in a row
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Best Streak
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-foreground">
                    {userStats?.longestStreak || 0}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    Personal record
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Weekly Progress Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Weekly Progress</CardTitle>
              </CardHeader>
              <CardContent>
                {progressLoading ? (
                  <div className="h-64 bg-muted rounded-lg animate-pulse"></div>
                ) : (
                  <ProgressChart data={weeklyProgress || []} />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shooting" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Shooting Accuracy</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {shootingLoading ? (
                    <div className="space-y-4">
                      <div className="h-4 bg-muted rounded animate-pulse"></div>
                      <div className="h-4 bg-muted rounded animate-pulse"></div>
                    </div>
                  ) : (
                    <>
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-foreground">Free Throw %</span>
                          <span className="text-sm text-primary font-bold">
                            {shootingStats?.freeThrowPercentage || 0}%
                          </span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-3">
                          <div 
                            className="bg-primary h-3 rounded-full transition-all duration-300" 
                            style={{ width: `${shootingStats?.freeThrowPercentage || 0}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-foreground">3-Point %</span>
                          <span className="text-sm text-secondary font-bold">
                            {shootingStats?.threePointPercentage || 0}%
                          </span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-3">
                          <div 
                            className="bg-secondary h-3 rounded-full transition-all duration-300" 
                            style={{ width: `${shootingStats?.threePointPercentage || 0}%` }}
                          ></div>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Shot Totals</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">Total Shots</p>
                      <p className="text-2xl font-bold text-primary">
                        {userStats?.shotsAttempted || 0}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Made</p>
                      <p className="text-xl font-bold text-foreground">
                        {userStats?.shotsMade || 0}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">Free Throws</p>
                      <p className="text-2xl font-bold text-primary">
                        {userStats?.freeThrowsAttempted || 0}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Made</p>
                      <p className="text-xl font-bold text-foreground">
                        {userStats?.freeThrowsMade || 0}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">Three-Pointers</p>
                      <p className="text-2xl font-bold text-primary">
                        {userStats?.threePointsAttempted || 0}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Made</p>
                      <p className="text-xl font-bold text-foreground">
                        {userStats?.threePointsMade || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="workouts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Workout History</CardTitle>
              </CardHeader>
              <CardContent>
                {sessionsLoading ? (
                  <div className="space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-16 bg-muted rounded-lg"></div>
                      </div>
                    ))}
                  </div>
                ) : recentSessions?.length ? (
                  <div className="space-y-4">
                    {recentSessions.map((session: any) => (
                      <div key={session.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <span className="text-primary">🏀</span>
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground">{session.workout.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {new Date(session.completedAt || session.startedAt).toLocaleDateString('en-US', {
                                weekday: 'short',
                                month: 'short', 
                                day: 'numeric'
                              })}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge 
                            variant={session.status === 'completed' ? 'default' : 'secondary'}
                            className={session.status === 'completed' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : ''}
                            data-testid={`badge-session-status-${session.id}`}
                          >
                            {session.status}
                          </Badge>
                          {session.totalDuration && (
                            <div className="text-sm text-muted-foreground mt-1">
                              {session.totalDuration} minutes
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">📊</div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">No workout history yet</h3>
                    <p className="text-muted-foreground mb-6">
                      Complete your first workout to start tracking your progress
                    </p>
                    <Button 
                      onClick={() => window.location.href = '/workouts'}
                      data-testid="button-start-tracking"
                    >
                      Start Your First Workout
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Achievements & Milestones</CardTitle>
              </CardHeader>
              <CardContent>
                {achievementsLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-24 bg-muted rounded-lg"></div>
                      </div>
                    ))}
                  </div>
                ) : userAchievements?.length ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {userAchievements.map((userAchievement: any) => (
                      <div 
                        key={userAchievement.id} 
                        className="p-4 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-lg border border-primary/20"
                      >
                        <div className="flex items-center space-x-3 mb-3">
                          <div className="text-3xl">{userAchievement.achievement.icon}</div>
                          <div>
                            <h4 className="font-semibold text-foreground">
                              {userAchievement.achievement.name}
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {userAchievement.achievement.description}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary" className="bg-primary/20 text-primary">
                            {userAchievement.achievement.type}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(userAchievement.earnedAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">🏆</div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">No achievements yet</h3>
                    <p className="text-muted-foreground mb-6">
                      Start working out to unlock your first achievement!
                    </p>
                    <Button 
                      onClick={() => window.location.href = '/workouts'}
                      data-testid="button-start-earning"
                    >
                      Start Earning Achievements
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
