import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { Brain, Sparkles, Target, Clock, Zap, Play, User, Settings, ChevronRight, Star, Eye } from "lucide-react";

type AIWorkout = {
  id: string;
  name: string;
  description: string;
  difficulty: string;
  estimatedDuration: number;
  workoutStructure: any;
  exerciseSelectionCriteria: any;
  tags: string[];
  personalizedReason: string;
  matchScore: number;
};

type UserPreferences = {
  skillLevel: string;
  primaryGoals: string[];
  workoutFrequency: number;
  intensityPreference: number;
  availableEquipment: string[];
  primaryPosition?: string;
  goataExperienceLevel?: string;
};

export default function AIWorkoutsPage() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedWorkouts, setGeneratedWorkouts] = useState<AIWorkout[]>([]);

  // Fetch user preferences
  const { data: preferences, isLoading: preferencesLoading } = useQuery({
    queryKey: ["/api/preferences"],
    enabled: !!user,
  });

  // Fetch AI workout templates
  const { data: templates = [], isLoading: templatesLoading } = useQuery({
    queryKey: ["/api/ai-workouts/templates"],
    enabled: !!user,
  });

  // Generate personalized workout mutation
  const generateWorkoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai-workouts/generate");
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedWorkouts(data.workouts || []);
      toast({
        title: "AI Workouts Generated!",
        description: `Created ${data.workouts?.length || 0} personalized workouts for you.`,
      });
      setIsGenerating(false);
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Unable to generate workouts. Please try again.",
        variant: "destructive",
      });
      setIsGenerating(false);
    },
  });

  const handleGenerateWorkouts = async () => {
    if (!preferences) {
      toast({
        title: "Setup Required",
        description: "Please set up your preferences first to get personalized workouts.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    generateWorkoutMutation.mutate();
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
      case "intermediate": return "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400";
      case "advanced": return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400";
    }
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600 dark:text-green-400";
    if (score >= 70) return "text-orange-600 dark:text-orange-400";
    return "text-gray-600 dark:text-gray-400";
  };

  const handleViewWorkout = (workout: AIWorkout) => {
    // Store the workout data temporarily for the detail page
    localStorage.setItem('ai-workout-detail', JSON.stringify(workout));
    setLocation(`/ai-workouts/${workout.id}`);
  };

  const handleStartWorkout = (workout: AIWorkout, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering the card click
    // Store the workout data and navigate to active workout
    localStorage.setItem('ai-workout-detail', JSON.stringify(workout));
    setLocation(`/ai-workouts/${workout.id}/active`);
  };

  if (authLoading || preferencesLoading || templatesLoading) {
    return (
      <div className="container mx-auto p-6 flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading AI workout generator...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl" data-testid="ai-workouts-page">
      <div className="space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Brain className="h-8 w-8 text-orange-500" />
            <h1 className="text-3xl font-bold text-foreground">AI Workout Generator</h1>
            <Sparkles className="h-6 w-6 text-orange-500" />
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get personalized basketball training programs powered by AI, tailored to your skill level, goals, and available equipment
          </p>
        </div>

        {/* Preferences Check */}
        {!preferences ? (
          <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
            <CardContent className="flex items-center justify-between p-6">
              <div className="flex items-center gap-3">
                <Settings className="h-6 w-6 text-orange-600" />
                <div>
                  <h3 className="font-semibold text-orange-800 dark:text-orange-200">Setup Required</h3>
                  <p className="text-sm text-orange-700 dark:text-orange-300">
                    Configure your preferences to unlock personalized AI workouts
                  </p>
                </div>
              </div>
              <Link href="/preferences">
                <Button className="bg-orange-600 hover:bg-orange-700" data-testid="button-setup-preferences">
                  Setup Preferences
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* User Profile Summary */}
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Your Training Profile
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Skill Level</div>
                    <Badge variant="outline" className="mt-1 capitalize">
                      {preferences.skillLevel}
                    </Badge>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Primary Goals</div>
                    <div className="text-sm font-medium mt-1">
                      {preferences.primaryGoals?.length || 0} selected
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Frequency</div>
                    <div className="text-sm font-medium mt-1">
                      {preferences.workoutFrequency}x/week
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Intensity</div>
                    <div className="text-sm font-medium mt-1">
                      {preferences.intensityPreference}/10
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Generate Workouts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-orange-500" />
                  Generate Personalized Workouts
                </CardTitle>
                <CardDescription>
                  AI will create custom basketball training programs based on your profile and goals
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-4">
                  <Button
                    onClick={handleGenerateWorkouts}
                    disabled={isGenerating}
                    size="lg"
                    className="bg-orange-500 hover:bg-orange-600"
                    data-testid="button-generate-workouts"
                  >
                    {isGenerating ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Brain className="h-4 w-4 mr-2" />
                        Generate AI Workouts
                      </>
                    )}
                  </Button>
                  
                  {!isGenerating && generatedWorkouts.length === 0 && (
                    <p className="text-sm text-muted-foreground">
                      Click to generate workouts tailored specifically to your goals and equipment
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Generated Workouts */}
            {generatedWorkouts.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Your Personalized Workouts</h2>
                  <Badge variant="outline" className="text-green-600 border-green-200">
                    {generatedWorkouts.length} workouts generated
                  </Badge>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  {generatedWorkouts.map((workout) => (
                    <Card 
                      key={workout.id} 
                      className="hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleViewWorkout(workout)}
                    >
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <CardTitle className="text-lg">{workout.name}</CardTitle>
                            <div className="flex items-center gap-2">
                              <Badge className={getDifficultyColor(workout.difficulty)}>
                                {workout.difficulty}
                              </Badge>
                              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {workout.estimatedDuration} min
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 text-yellow-500" />
                              <span className={`font-semibold ${getMatchScoreColor(workout.matchScore)}`}>
                                {workout.matchScore}%
                              </span>
                            </div>
                            <div className="text-xs text-muted-foreground">match</div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-sm text-muted-foreground">{workout.description}</p>
                        
                        {workout.personalizedReason && (
                          <div className="p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                            <div className="flex items-start gap-2">
                              <Target className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                              <div>
                                <div className="text-sm font-medium text-orange-800 dark:text-orange-200">
                                  Why this workout?
                                </div>
                                <div className="text-sm text-orange-700 dark:text-orange-300">
                                  {workout.personalizedReason}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {workout.tags && workout.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {workout.tags.slice(0, 3).map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                            {workout.tags.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{workout.tags.length - 3} more
                              </Badge>
                            )}
                          </div>
                        )}

                        <Separator />
                        
                        <div className="flex justify-between items-center">
                          <div className="text-sm text-muted-foreground">
                            AI Generated • Personalized
                          </div>
                          <div className="flex items-center gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleViewWorkout(workout)}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <Button 
                              size="sm" 
                              className="bg-orange-500 hover:bg-orange-600"
                              onClick={(e) => handleStartWorkout(workout, e)}
                              data-testid={`button-start-workout-${workout.id}`}
                            >
                              <Play className="h-3 w-3 mr-1" />
                              Start
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="text-center">
                  <Button
                    variant="outline"
                    onClick={handleGenerateWorkouts}
                    disabled={isGenerating}
                    data-testid="button-regenerate-workouts"
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate New Workouts
                  </Button>
                </div>
              </div>
            )}

            {/* Available Templates Preview */}
            {templates.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Available AI Templates
                  </CardTitle>
                  <CardDescription>
                    Pre-built workout templates that can be personalized for you
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                    {templates.slice(0, 6).map((template: any) => (
                      <div key={template.id} className="p-3 border rounded-lg">
                        <div className="font-medium text-sm">{template.name}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {template.difficulty} • {template.estimatedDuration} min
                        </div>
                        <div className="text-xs text-muted-foreground mt-2">
                          {template.description}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* Information Cards */}
        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">How AI Workouts Work</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span>Analyzes your skill level and goals</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span>Considers available equipment and time</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span>Integrates GOATA movement principles</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span>Creates progressive training sequences</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Personalization Factors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div>• Basketball position and playing style</div>
                <div>• Current fitness level and experience</div>
                <div>• Training goals and preferences</div>
                <div>• Available equipment and locations</div>
                <div>• Injury history and limitations</div>
                <div>• GOATA methodology experience</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}