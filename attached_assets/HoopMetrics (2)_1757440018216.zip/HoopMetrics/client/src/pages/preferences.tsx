import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { User, Target, Dumbbell, MapPin, Clock, Brain, Heart, TrendingUp, Save } from "lucide-react";

type UserWorkoutPreferences = {
  id?: string;
  userId: string;
  skillLevel: string;
  primaryPosition?: string;
  secondaryPositions?: string[];
  playingStyle?: string;
  experienceYears?: number;
  height?: number;
  weight?: number;
  injuryHistory?: string[];
  currentLimitations?: string[];
  primaryGoals: string[];
  secondaryGoals?: string[];
  workoutFrequency?: number;
  sessionDurationPreference?: number;
  intensityPreference?: number;
  availableEquipment?: string[];
  trainingLocations?: string[];
  preferredWorkoutTimes?: string[];
  methodologyWeights?: Record<string, number>;
  goataExperienceLevel?: string;
  plyometricReadiness?: string;
  wearableTargets?: Record<string, number>;
};

const skillLevels = [
  { value: "beginner", label: "Beginner", description: "New to basketball or fitness training" },
  { value: "intermediate", label: "Intermediate", description: "Some experience with basketball and fitness" },
  { value: "advanced", label: "Advanced", description: "Experienced player with solid fitness foundation" },
];

const positions = [
  { value: "guard", label: "Point Guard / Shooting Guard" },
  { value: "forward", label: "Small Forward / Power Forward" },
  { value: "center", label: "Center" },
];

const playingStyles = [
  { value: "athletic", label: "Athletic", description: "Fast, explosive, physical play" },
  { value: "technical", label: "Technical", description: "Skill-focused, precision-based play" },
  { value: "cerebral", label: "Cerebral", description: "Strategic, game-IQ focused play" },
];

const primaryGoals = [
  "Improve shooting accuracy",
  "Increase vertical jump",
  "Build overall strength",
  "Enhance ball handling",
  "Improve conditioning",
  "Develop game IQ",
  "Injury prevention",
  "Increase speed/agility",
  "Better defense",
  "Gain muscle mass",
];

const equipment = [
  "Basketball",
  "Gym access",
  "Dumbbells",
  "Resistance bands",
  "Medicine ball",
  "Agility ladder",
  "Cones",
  "Pull-up bar",
  "Plyometric box",
  "Battle ropes",
];

const locations = [
  "Home",
  "Gym",
  "Basketball court",
  "Park/Outdoor",
  "School facility",
];

const workoutTimes = [
  "Early morning (5-8 AM)",
  "Morning (8-11 AM)",
  "Midday (11 AM-2 PM)",
  "Afternoon (2-5 PM)",
  "Evening (5-8 PM)",
  "Night (8-11 PM)",
];

export default function PreferencesPage() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [preferences, setPreferences] = useState<UserWorkoutPreferences>({
    userId: user?.id || "",
    skillLevel: "",
    primaryGoals: [],
    intensityPreference: 7,
    workoutFrequency: 3,
    sessionDurationPreference: 45,
    methodologyWeights: {
      traditional: 50,
      goata: 30,
      functional: 20,
    },
    goataExperienceLevel: "none",
    plyometricReadiness: "basic",
  });

  // Fetch existing preferences
  const { data: existingPreferences, isLoading } = useQuery({
    queryKey: ["/api/preferences"],
    enabled: !!user,
  });

  // Load existing preferences when data arrives
  useEffect(() => {
    if (existingPreferences) {
      setPreferences({
        ...preferences,
        ...existingPreferences,
        primaryGoals: existingPreferences.primaryGoals || [],
        secondaryGoals: existingPreferences.secondaryGoals || [],
        secondaryPositions: existingPreferences.secondaryPositions || [],
        injuryHistory: existingPreferences.injuryHistory || [],
        currentLimitations: existingPreferences.currentLimitations || [],
        availableEquipment: existingPreferences.availableEquipment || [],
        trainingLocations: existingPreferences.trainingLocations || [],
        preferredWorkoutTimes: existingPreferences.preferredWorkoutTimes || [],
        methodologyWeights: existingPreferences.methodologyWeights || {
          traditional: 50,
          goata: 30,
          functional: 20,
        },
        wearableTargets: existingPreferences.wearableTargets || {},
      });
    }
  }, [existingPreferences]);

  // Save preferences mutation
  const savePreferencesMutation = useMutation({
    mutationFn: async (data: UserWorkoutPreferences) => {
      await apiRequest("POST", "/api/preferences", data);
    },
    onSuccess: () => {
      toast({
        title: "Preferences Saved!",
        description: "Your workout preferences have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/preferences"] });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save your preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    if (!preferences.skillLevel || preferences.primaryGoals.length === 0) {
      toast({
        title: "Missing Required Fields",
        description: "Please select your skill level and at least one primary goal.",
        variant: "destructive",
      });
      return;
    }

    savePreferencesMutation.mutate({
      ...preferences,
      userId: user?.id || "",
    });
  };

  const toggleArrayItem = (array: string[], item: string): string[] => {
    if (array.includes(item)) {
      return array.filter(i => i !== item);
    }
    return [...array, item];
  };

  if (authLoading || isLoading) {
    return (
      <div className="container mx-auto p-6 flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading preferences...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl" data-testid="preferences-page">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Workout Preferences</h1>
            <p className="text-muted-foreground mt-2">
              Personalize your training with AI-powered workout recommendations
            </p>
          </div>
          
          <Button
            onClick={handleSave}
            disabled={savePreferencesMutation.isPending}
            className="bg-orange-500 hover:bg-orange-600"
            data-testid="button-save-preferences"
          >
            <Save className="h-4 w-4 mr-2" />
            {savePreferencesMutation.isPending ? "Saving..." : "Save Preferences"}
          </Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Athletic Profile */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Athletic Profile
              </CardTitle>
              <CardDescription>Tell us about your basketball background</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="skillLevel">Skill Level *</Label>
                <Select 
                  value={preferences.skillLevel} 
                  onValueChange={(value) => setPreferences({...preferences, skillLevel: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your skill level" />
                  </SelectTrigger>
                  <SelectContent>
                    {skillLevels.map((level) => (
                      <SelectItem key={level.value} value={level.value}>
                        <div>
                          <div className="font-medium">{level.label}</div>
                          <div className="text-sm text-muted-foreground">{level.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="primaryPosition">Primary Position</Label>
                <Select 
                  value={preferences.primaryPosition || ""} 
                  onValueChange={(value) => setPreferences({...preferences, primaryPosition: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your position" />
                  </SelectTrigger>
                  <SelectContent>
                    {positions.map((position) => (
                      <SelectItem key={position.value} value={position.value}>
                        {position.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="playingStyle">Playing Style</Label>
                <Select 
                  value={preferences.playingStyle || ""} 
                  onValueChange={(value) => setPreferences({...preferences, playingStyle: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="How do you like to play?" />
                  </SelectTrigger>
                  <SelectContent>
                    {playingStyles.map((style) => (
                      <SelectItem key={style.value} value={style.value}>
                        <div>
                          <div className="font-medium">{style.label}</div>
                          <div className="text-sm text-muted-foreground">{style.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="experienceYears">Years of Experience</Label>
                <Input
                  id="experienceYears"
                  type="number"
                  value={preferences.experienceYears || ""}
                  onChange={(e) => setPreferences({...preferences, experienceYears: parseInt(e.target.value) || 0})}
                  placeholder="Years playing basketball"
                />
              </div>
            </CardContent>
          </Card>

          {/* Physical Profile */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5" />
                Physical Profile
              </CardTitle>
              <CardDescription>Help us tailor your training intensity</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    value={preferences.height || ""}
                    onChange={(e) => setPreferences({...preferences, height: parseInt(e.target.value) || 0})}
                    placeholder="175"
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    value={preferences.weight || ""}
                    onChange={(e) => setPreferences({...preferences, weight: parseFloat(e.target.value) || 0})}
                    placeholder="70"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="currentLimitations">Current Limitations</Label>
                <Textarea
                  id="currentLimitations"
                  value={preferences.currentLimitations?.join(", ") || ""}
                  onChange={(e) => setPreferences({
                    ...preferences, 
                    currentLimitations: e.target.value ? e.target.value.split(", ").map(s => s.trim()) : []
                  })}
                  placeholder="Any injuries or physical limitations (optional)"
                  rows={2}
                />
              </div>

              <div>
                <Label>Intensity Preference: {preferences.intensityPreference}/10</Label>
                <Slider
                  value={[preferences.intensityPreference || 7]}
                  onValueChange={(value) => setPreferences({...preferences, intensityPreference: value[0]})}
                  max={10}
                  min={1}
                  step={1}
                  className="mt-2"
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>Light</span>
                  <span>Intense</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Training Goals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Training Goals
              </CardTitle>
              <CardDescription>What do you want to achieve? *</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Primary Goals (select at least one)</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {primaryGoals.map((goal) => (
                    <div key={goal} className="flex items-center space-x-2">
                      <Checkbox
                        id={goal}
                        checked={preferences.primaryGoals.includes(goal)}
                        onCheckedChange={() => setPreferences({
                          ...preferences,
                          primaryGoals: toggleArrayItem(preferences.primaryGoals, goal)
                        })}
                      />
                      <Label htmlFor={goal} className="text-sm">
                        {goal}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Training Schedule */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Training Schedule
              </CardTitle>
              <CardDescription>When and how often do you train?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Workout Frequency: {preferences.workoutFrequency} times/week</Label>
                <Slider
                  value={[preferences.workoutFrequency || 3]}
                  onValueChange={(value) => setPreferences({...preferences, workoutFrequency: value[0]})}
                  max={7}
                  min={1}
                  step={1}
                  className="mt-2"
                />
              </div>

              <div>
                <Label>Session Duration: {preferences.sessionDurationPreference} minutes</Label>
                <Slider
                  value={[preferences.sessionDurationPreference || 45]}
                  onValueChange={(value) => setPreferences({...preferences, sessionDurationPreference: value[0]})}
                  max={120}
                  min={15}
                  step={15}
                  className="mt-2"
                />
              </div>

              <div>
                <Label>Preferred Workout Times</Label>
                <div className="grid gap-2 mt-2">
                  {workoutTimes.map((time) => (
                    <div key={time} className="flex items-center space-x-2">
                      <Checkbox
                        id={time}
                        checked={preferences.preferredWorkoutTimes?.includes(time) || false}
                        onCheckedChange={() => setPreferences({
                          ...preferences,
                          preferredWorkoutTimes: toggleArrayItem(preferences.preferredWorkoutTimes || [], time)
                        })}
                      />
                      <Label htmlFor={time} className="text-sm">
                        {time}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Equipment & Location */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dumbbell className="h-5 w-5" />
                Equipment & Location
              </CardTitle>
              <CardDescription>What equipment and locations are available?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Available Equipment</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {equipment.map((item) => (
                    <div key={item} className="flex items-center space-x-2">
                      <Checkbox
                        id={item}
                        checked={preferences.availableEquipment?.includes(item) || false}
                        onCheckedChange={() => setPreferences({
                          ...preferences,
                          availableEquipment: toggleArrayItem(preferences.availableEquipment || [], item)
                        })}
                      />
                      <Label htmlFor={item} className="text-sm">
                        {item}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>Training Locations</Label>
                <div className="grid gap-2 mt-2">
                  {locations.map((location) => (
                    <div key={location} className="flex items-center space-x-2">
                      <Checkbox
                        id={location}
                        checked={preferences.trainingLocations?.includes(location) || false}
                        onCheckedChange={() => setPreferences({
                          ...preferences,
                          trainingLocations: toggleArrayItem(preferences.trainingLocations || [], location)
                        })}
                      />
                      <Label htmlFor={location} className="text-sm">
                        {location}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Training Methodology */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Training Methodology
              </CardTitle>
              <CardDescription>Choose your preferred training approaches</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="goataExperience">GOATA Experience Level</Label>
                <Select 
                  value={preferences.goataExperienceLevel || "none"} 
                  onValueChange={(value) => setPreferences({...preferences, goataExperienceLevel: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Experience</SelectItem>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="plyometricReadiness">Plyometric Readiness</Label>
                <Select 
                  value={preferences.plyometricReadiness || "basic"} 
                  onValueChange={(value) => setPreferences({...preferences, plyometricReadiness: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Plyometrics</SelectItem>
                    <SelectItem value="basic">Basic Level</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Methodology Focus</Label>
                <div className="space-y-3 mt-2">
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>Traditional Training</span>
                      <span>{preferences.methodologyWeights?.traditional || 50}%</span>
                    </div>
                    <Slider
                      value={[preferences.methodologyWeights?.traditional || 50]}
                      onValueChange={(value) => setPreferences({
                        ...preferences,
                        methodologyWeights: {
                          ...preferences.methodologyWeights,
                          traditional: value[0]
                        }
                      })}
                      max={100}
                      min={0}
                      step={10}
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>GOATA Movement</span>
                      <span>{preferences.methodologyWeights?.goata || 30}%</span>
                    </div>
                    <Slider
                      value={[preferences.methodologyWeights?.goata || 30]}
                      onValueChange={(value) => setPreferences({
                        ...preferences,
                        methodologyWeights: {
                          ...preferences.methodologyWeights,
                          goata: value[0]
                        }
                      })}
                      max={100}
                      min={0}
                      step={10}
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>Functional Training</span>
                      <span>{preferences.methodologyWeights?.functional || 20}%</span>
                    </div>
                    <Slider
                      value={[preferences.methodologyWeights?.functional || 20]}
                      onValueChange={(value) => setPreferences({
                        ...preferences,
                        methodologyWeights: {
                          ...preferences.methodologyWeights,
                          functional: value[0]
                        }
                      })}
                      max={100}
                      min={0}
                      step={10}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Preview Section */}
        {preferences.skillLevel && preferences.primaryGoals.length > 0 && (
          <Card className="bg-gradient-to-r from-orange-50 to-blue-50 dark:from-orange-950/20 dark:to-blue-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Your Training Profile
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">Skill Level</div>
                  <Badge variant="outline" className="mt-1">
                    {skillLevels.find(s => s.value === preferences.skillLevel)?.label}
                  </Badge>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Primary Goals</div>
                  <div className="text-sm font-medium mt-1">
                    {preferences.primaryGoals.length} selected
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Frequency</div>
                  <div className="text-sm font-medium mt-1">
                    {preferences.workoutFrequency}x/week
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Intensity</div>
                  <div className="text-sm font-medium mt-1">
                    {preferences.intensityPreference}/10
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}