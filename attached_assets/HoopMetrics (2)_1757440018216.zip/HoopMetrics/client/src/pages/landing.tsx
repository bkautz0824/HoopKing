import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-0">
          <div className="grid md:grid-cols-2 gap-0">
            {/* Left side - Hero content */}
            <div className="p-8 md:p-12 flex flex-col justify-center">
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground text-lg">🏀</span>
                </div>
                <h1 className="text-3xl font-bold text-foreground">CourtFit</h1>
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4 leading-tight">
                Elevate Your 
                <span className="text-primary block">Basketball Game</span>
              </h2>
              
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Professional workout plans, progress tracking, and achievement systems designed to take your basketball skills to the next level.
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-primary text-sm">✓</span>
                  </div>
                  <span className="text-foreground">Pre-built gym and court workouts</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-primary text-sm">✓</span>
                  </div>
                  <span className="text-foreground">Real-time progress analytics</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-primary text-sm">✓</span>
                  </div>
                  <span className="text-foreground">Achievement tracking system</span>
                </div>
              </div>
              
              <Button 
                onClick={() => window.location.href = '/api/login'}
                size="lg"
                className="w-full md:w-auto bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8"
                data-testid="button-login"
              >
                Start Training Today
              </Button>
              
              <p className="text-sm text-muted-foreground mt-4">
                Join thousands of players improving their game
              </p>
            </div>
            
            {/* Right side - Visual */}
            <div className="relative bg-gradient-to-br from-primary to-secondary p-8 md:p-12 flex items-center justify-center">
              <div className="text-center text-primary-foreground">
                <div className="w-32 h-32 bg-primary-foreground/20 rounded-full flex items-center justify-center mb-6 mx-auto">
                  <span className="text-6xl">🏀</span>
                </div>
                <h3 className="text-2xl font-bold mb-4">Professional Training</h3>
                <p className="text-primary-foreground/80 leading-relaxed">
                  Access elite basketball workouts used by professionals and collegiate athletes worldwide.
                </p>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute top-4 right-4 w-20 h-20 bg-primary-foreground/10 rounded-full"></div>
              <div className="absolute bottom-4 left-4 w-16 h-16 bg-primary-foreground/10 rounded-full"></div>
              <div className="absolute top-1/2 left-4 w-12 h-12 bg-primary-foreground/10 rounded-full"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
