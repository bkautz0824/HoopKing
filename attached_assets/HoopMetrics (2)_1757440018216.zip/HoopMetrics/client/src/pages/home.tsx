import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import StatsOverview from "@/components/stats-overview";
import WorkoutCard from "@/components/workout-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";

export default function Home() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: featuredWorkouts, isLoading: workoutsLoading } = useQuery({
    queryKey: ["/api/workouts/featured"],
    enabled: isAuthenticated,
  });

  const { data: recentSessions, isLoading: sessionsLoading } = useQuery({
    queryKey: ["/api/sessions/recent"],
    enabled: isAuthenticated,
  });

  const { data: activeSession } = useQuery({
    queryKey: ["/api/sessions/active"],
    enabled: isAuthenticated,
  });

  const { data: userStats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  const handleStartWorkout = (workoutId: string) => {
    setLocation(`/workouts/${workoutId}`);
  };

  const handleQuickStart = () => {
    setLocation("/workouts");
  };

  return (
    <div className="min-h-screen bg-background">
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            Welcome back, <span className="text-primary">{user?.firstName || 'Champion'}</span>! 🏀
          </h1>
          <p className="text-muted-foreground text-lg">Ready to take your game to the next level?</p>
        </div>

        {/* Active Workout Alert */}
        {activeSession && (
          <Card className="mb-8 border-primary bg-primary/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-1">
                    Active Workout in Progress
                  </h3>
                  <p className="text-muted-foreground">
                    Continue your workout from where you left off
                  </p>
                </div>
                <Button 
                  onClick={() => setLocation(`/workout/${activeSession.workoutId}/active`)}
                  className="bg-primary hover:bg-primary/90"
                  data-testid="button-continue-workout"
                >
                  Continue
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats Overview */}
        <StatsOverview userStats={userStats} />

        {/* Featured Workouts */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Featured Workouts</h2>
            <Button 
              variant="outline"
              onClick={() => setLocation("/workouts")}
              data-testid="button-view-all-workouts"
            >
              View All
            </Button>
          </div>
          
          {workoutsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-48 bg-muted rounded-xl mb-4"></div>
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-3 bg-muted rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredWorkouts?.map((workout: any) => (
                <WorkoutCard 
                  key={workout.id}
                  workout={workout}
                  onStart={handleStartWorkout}
                />
              ))}
            </div>
          )}
        </div>

        {/* Recent Activity & Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Workouts */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {sessionsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-16 bg-muted rounded-lg"></div>
                      </div>
                    ))}
                  </div>
                ) : recentSessions?.length ? (
                  <div className="space-y-4">
                    {recentSessions.slice(0, 5).map((session: any) => (
                      <div key={session.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <span className="text-primary">🏀</span>
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground">{session.workout.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {new Date(session.completedAt || session.startedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge 
                            variant={session.status === 'completed' ? 'default' : 'secondary'}
                            data-testid={`badge-status-${session.id}`}
                          >
                            {session.status}
                          </Badge>
                          {session.totalDuration && (
                            <div className="text-xs text-muted-foreground mt-1">
                              {session.totalDuration} min
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No recent workouts</p>
                    <Button 
                      onClick={handleQuickStart}
                      className="mt-4"
                      data-testid="button-start-first-workout"
                    >
                      Start Your First Workout
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Start</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full bg-primary hover:bg-primary/90"
                  onClick={handleQuickStart}
                  data-testid="button-quick-start"
                >
                  🏃‍♂️ 15-Min Quick Drill
                </Button>
                <Button 
                  variant="outline"
                  className="w-full"
                  onClick={() => setLocation("/progress")}
                  data-testid="button-view-progress"
                >
                  📊 View Progress
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Today's Goal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="relative w-20 h-20 mx-auto mb-4">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                      <circle 
                        cx="50" cy="50" r="40" 
                        stroke="hsl(var(--muted))" 
                        strokeWidth="8" 
                        fill="transparent" 
                      />
                      <circle 
                        cx="50" cy="50" r="40" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth="8" 
                        fill="transparent"
                        strokeDasharray="251.2" 
                        strokeDashoffset="75.36"
                        className="progress-ring" 
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-lg font-bold text-foreground">70%</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">Weekly workout goal</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Floating Action Button */}
      <Button
        className="fixed bottom-6 right-6 rounded-full w-14 h-14 bg-primary hover:bg-primary/90 shadow-lg"
        onClick={handleQuickStart}
        data-testid="button-fab-quick-start"
      >
        <span className="text-xl">+</span>
      </Button>
    </div>
  );
}
