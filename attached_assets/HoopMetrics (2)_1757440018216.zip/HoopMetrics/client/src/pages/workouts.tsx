import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import WorkoutCard from "@/components/workout-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Workouts() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [, setLocation] = useLocation();

  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/workout-categories"],
  });

  const { data: workouts, isLoading: workoutsLoading } = useQuery({
    queryKey: selectedCategory ? [`/api/workouts/category/${selectedCategory}`] : ["/api/workouts"],
  });

  const handleStartWorkout = (workoutId: string) => {
    setLocation(`/workouts/${workoutId}`);
  };

  return (
    <div className="min-h-screen bg-background">
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            Workout Library
          </h1>
          <p className="text-muted-foreground text-lg">
            Choose from our collection of professional basketball training programs
          </p>
        </div>

        {/* Category Selection */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-4">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              data-testid="button-category-all"
            >
              All Workouts
            </Button>
            {categoriesLoading ? (
              <div className="flex gap-4">
                {[...Array(2)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-10 w-24 bg-muted rounded-lg"></div>
                  </div>
                ))}
              </div>
            ) : (
              categories?.map((category: any) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.id)}
                  data-testid={`button-category-${category.name.toLowerCase().replace(' ', '-')}`}
                >
                  {category.icon && <span className="mr-2">{category.icon}</span>}
                  {category.name}
                </Button>
              ))
            )}
          </div>
        </div>

        {/* Category Description */}
        {selectedCategory && categories && (
          <Card className="mb-8">
            <CardContent className="p-6">
              {(() => {
                const category = categories.find((c: any) => c.id === selectedCategory);
                return category ? (
                  <div className="flex items-center space-x-4">
                    <div className="text-4xl">{category.icon}</div>
                    <div>
                      <h2 className="text-2xl font-bold text-foreground mb-2">{category.name}</h2>
                      <p className="text-muted-foreground">{category.description}</p>
                    </div>
                  </div>
                ) : null;
              })()}
            </CardContent>
          </Card>
        )}

        {/* Workouts Grid */}
        {workoutsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-48 bg-muted rounded-t-xl"></div>
                <div className="p-6 bg-card rounded-b-xl border border-t-0">
                  <div className="h-6 bg-muted rounded mb-2"></div>
                  <div className="h-4 bg-muted rounded mb-4"></div>
                  <div className="h-10 bg-muted rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : workouts?.length ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {workouts.map((workout: any) => (
              <WorkoutCard 
                key={workout.id}
                workout={workout}
                onStart={handleStartWorkout}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <div className="text-6xl mb-4">🏀</div>
              <h3 className="text-xl font-semibold text-foreground mb-2">No workouts found</h3>
              <p className="text-muted-foreground mb-6">
                {selectedCategory 
                  ? "No workouts available in this category yet." 
                  : "No workouts available at the moment."
                }
              </p>
              {selectedCategory && (
                <Button onClick={() => setSelectedCategory(null)}>
                  View All Workouts
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
