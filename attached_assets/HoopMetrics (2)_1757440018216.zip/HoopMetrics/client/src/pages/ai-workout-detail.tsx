import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Play, 
  Clock, 
  Target, 
  Star, 
  Brain, 
  Dumbbell, 
  Users, 
  ChevronLeft,
  CheckCircle,
  AlertCircle,
  Zap
} from "lucide-react";

interface AIWorkoutDetailProps {
  params: {
    id: string;
  };
}

type AIWorkout = {
  id: string;
  name: string;
  description: string;
  difficulty: string;
  estimatedDuration: number;
  workoutStructure: any;
  exerciseSelectionCriteria: any;
  tags: string[];
  personalizedReason: string;
  matchScore: number;
};

export default function AIWorkoutDetail({ params }: AIWorkoutDetailProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [workout, setWorkout] = useState<AIWorkout | null>(null);
  const workoutId = params.id;

  useEffect(() => {
    // Load workout from localStorage (stored by AI workouts page)
    const storedWorkout = localStorage.getItem('ai-workout-detail');
    if (storedWorkout) {
      try {
        const parsedWorkout = JSON.parse(storedWorkout);
        if (parsedWorkout.id === workoutId) {
          setWorkout(parsedWorkout);
        } else {
          // If IDs don't match, go back to AI workouts
          setLocation('/ai-workouts');
        }
      } catch (error) {
        console.error('Failed to parse workout data:', error);
        setLocation('/ai-workouts');
      }
    } else {
      setLocation('/ai-workouts');
    }
  }, [workoutId, setLocation]);

  const handleStartWorkout = () => {
    if (workout) {
      setLocation(`/ai-workouts/${workout.id}/active`);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
      case "intermediate": return "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400";
      case "advanced": return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400";
    }
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600 dark:text-green-400";
    if (score >= 70) return "text-orange-600 dark:text-orange-400";
    return "text-gray-600 dark:text-gray-400";
  };

  if (!workout) {
    return (
      <div className="container mx-auto p-6 flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading workout details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="space-y-6">
        {/* Back Button */}
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/ai-workouts')}
          className="mb-4"
          data-testid="button-back-to-ai-workouts"
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Back to AI Workouts
        </Button>

        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Brain className="h-8 w-8 text-orange-500" />
            <h1 className="text-3xl font-bold text-foreground">{workout.name}</h1>
          </div>
          <div className="flex items-center justify-center gap-4">
            <Badge className={getDifficultyColor(workout.difficulty)}>
              {workout.difficulty}
            </Badge>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Clock className="h-4 w-4" />
              {workout.estimatedDuration} minutes
            </div>
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500" />
              <span className={`font-semibold ${getMatchScoreColor(workout.matchScore)}`}>
                {workout.matchScore}% match
              </span>
            </div>
          </div>
        </div>

        {/* Description */}
        <Card>
          <CardHeader>
            <CardTitle>About This Workout</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">{workout.description}</p>
            {workout.personalizedReason && (
              <div className="p-4 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                <div className="flex items-start gap-3">
                  <Target className="h-5 w-5 text-orange-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-orange-800 dark:text-orange-200 mb-2">
                      Why This Workout Was Selected For You
                    </div>
                    <div className="text-orange-700 dark:text-orange-300">
                      {workout.personalizedReason}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Workout Structure */}
        {workout.workoutStructure && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dumbbell className="h-5 w-5" />
                Workout Structure
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-orange-500 mb-2">
                    {workout.workoutStructure.warmUp || 10}m
                  </div>
                  <div className="text-sm text-muted-foreground">Warm-Up</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-orange-500 mb-2">
                    {workout.workoutStructure.mainWork || 25}m
                  </div>
                  <div className="text-sm text-muted-foreground">Main Training</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-orange-500 mb-2">
                    {workout.workoutStructure.coolDown || 5}m
                  </div>
                  <div className="text-sm text-muted-foreground">Cool Down</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Exercise Selection Criteria */}
        {workout.exerciseSelectionCriteria && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Personalization Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {workout.exerciseSelectionCriteria.equipment && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      Equipment Used
                    </h4>
                    <div className="space-y-2">
                      {workout.exerciseSelectionCriteria.equipment.map((item: string, index: number) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Zap className="h-4 w-4 text-orange-500" />
                    Training Focus
                  </h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      Intensity: {workout.exerciseSelectionCriteria.intensity || 'Moderate'}/10
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      Court Access: {workout.exerciseSelectionCriteria.courtAccess ? 'Yes' : 'No'}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tags */}
        {workout.tags && workout.tags.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Training Tags</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {workout.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Start Workout */}
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <div>
                <h3 className="text-lg font-semibold text-orange-800 dark:text-orange-200 mb-2">
                  Ready to Start Training?
                </h3>
                <p className="text-orange-700 dark:text-orange-300">
                  This AI-generated workout is personalized for your skill level and goals
                </p>
              </div>
              <Button 
                size="lg" 
                onClick={handleStartWorkout}
                className="bg-orange-500 hover:bg-orange-600"
                data-testid="button-start-ai-workout"
              >
                <Play className="h-5 w-5 mr-2" />
                Start Workout ({workout.estimatedDuration} min)
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}