import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

interface WorkoutDetailProps {
  params: {
    id: string;
  };
}

export default function WorkoutDetail({ params }: WorkoutDetailProps) {
  const [, setLocation] = useLocation();
  const workoutId = params.id;

  const { data: workout, isLoading, error } = useQuery({
    queryKey: [`/api/workouts/${workoutId}`],
    enabled: !!workoutId,
  });

  const startWorkoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/sessions', {
        workoutId,
        status: 'in_progress',
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      setLocation(`/workout/${workoutId}/active`);
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-64 bg-muted rounded-xl"></div>
            <div className="h-8 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-muted rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !workout) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <div className="text-6xl mb-4">❌</div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Workout Not Found</h2>
              <p className="text-muted-foreground mb-6">
                The workout you're looking for doesn't exist or has been removed.
              </p>
              <Button onClick={() => setLocation("/workouts")}>
                Back to Workouts
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const difficultyColors = {
    beginner: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    intermediate: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300', 
    advanced: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
  };

  return (
    <div className="min-h-screen bg-background">
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <Card className="mb-8 overflow-hidden">
          <div className="relative">
            {workout.imageUrl ? (
              <div 
                className="h-64 bg-cover bg-center"
                style={{ backgroundImage: `url(${workout.imageUrl})` }}
              />
            ) : (
              <div className="h-64 bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <span className="text-8xl text-primary-foreground opacity-80">🏀</span>
              </div>
            )}
            <div className="absolute top-4 left-4 space-x-2">
              <Badge className={difficultyColors[workout.difficulty as keyof typeof difficultyColors] || difficultyColors.beginner}>
                {workout.difficulty}
              </Badge>
              <Badge variant="secondary" className="bg-black/20 text-white border-0">
                {workout.category?.name || 'Training'}
              </Badge>
            </div>
          </div>
          
          <CardContent className="p-8">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  {workout.name}
                </h1>
                {workout.description && (
                  <p className="text-lg text-muted-foreground">
                    {workout.description}
                  </p>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-6 mb-6">
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-foreground">{workout.duration}</div>
                <div className="text-sm text-muted-foreground">Minutes</div>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-foreground">{workout.exercises?.length || 0}</div>
                <div className="text-sm text-muted-foreground">Exercises</div>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-foreground">{workout.difficulty}</div>
                <div className="text-sm text-muted-foreground">Difficulty</div>
              </div>
            </div>
            
            <Button 
              onClick={() => startWorkoutMutation.mutate()}
              disabled={startWorkoutMutation.isPending}
              size="lg"
              className="w-full bg-primary hover:bg-primary/90"
              data-testid="button-start-workout"
            >
              {startWorkoutMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2"></div>
                  Starting...
                </>
              ) : (
                <>
                  🚀 Start Workout
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Exercises */}
        <Card>
          <CardHeader>
            <CardTitle>Workout Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {workout.exercises?.length ? (
              <div className="space-y-4">
                {workout.exercises.map((exercise: any, index: number) => (
                  <div key={exercise.id}>
                    <div className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <span className="text-primary font-bold">{index + 1}</span>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground mb-1">{exercise.name}</h3>
                        {exercise.description && (
                          <p className="text-sm text-muted-foreground mb-2">{exercise.description}</p>
                        )}
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          {exercise.sets && (
                            <span>📊 {exercise.sets} sets</span>
                          )}
                          {exercise.reps && (
                            <span>🔢 {exercise.reps} reps</span>
                          )}
                          {exercise.duration && (
                            <span>⏱️ {exercise.duration}s</span>
                          )}
                          {exercise.restTime && (
                            <span>😴 {exercise.restTime}s rest</span>
                          )}
                        </div>
                        {exercise.instructions && (
                          <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Instructions:</h4>
                            <p className="text-sm text-blue-800 dark:text-blue-200">{exercise.instructions}</p>
                          </div>
                        )}
                        {exercise.tips && (
                          <div className="mt-2 p-3 bg-amber-50 dark:bg-amber-950 rounded-lg">
                            <h4 className="font-medium text-amber-900 dark:text-amber-100 mb-1">💡 Tips:</h4>
                            <p className="text-sm text-amber-800 dark:text-amber-200">{exercise.tips}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    {index < workout.exercises.length - 1 && <Separator className="my-4" />}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No exercises defined for this workout.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
