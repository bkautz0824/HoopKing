import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Clock, 
  Play, 
  Pause, 
  SkipForward, 
  ChevronLeft,
  CheckCircle,
  Target,
  Brain,
  Trophy
} from "lucide-react";

interface AIWorkoutActiveProps {
  params: {
    id: string;
  };
}

type AIWorkout = {
  id: string;
  name: string;
  description: string;
  difficulty: string;
  estimatedDuration: number;
  workoutStructure: any;
  exerciseSelectionCriteria: any;
  tags: string[];
  personalizedReason: string;
  matchScore: number;
};

export default function AIWorkoutActive({ params }: AIWorkoutActiveProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [workout, setWorkout] = useState<AIWorkout | null>(null);
  const [currentPhase, setCurrentPhase] = useState<'warmup' | 'main' | 'cooldown'>('warmup');
  const [timeLeft, setTimeLeft] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [totalElapsed, setTotalElapsed] = useState(0);
  const workoutId = params.id;

  useEffect(() => {
    // Load workout from localStorage
    const storedWorkout = localStorage.getItem('ai-workout-detail');
    if (storedWorkout) {
      try {
        const parsedWorkout = JSON.parse(storedWorkout);
        if (parsedWorkout.id === workoutId) {
          setWorkout(parsedWorkout);
          // Set initial time for warm-up
          const warmupTime = (parsedWorkout.workoutStructure?.warmUp || 10) * 60;
          setTimeLeft(warmupTime);
        } else {
          setLocation('/ai-workouts');
        }
      } catch (error) {
        console.error('Failed to parse workout data:', error);
        setLocation('/ai-workouts');
      }
    } else {
      setLocation('/ai-workouts');
    }
  }, [workoutId, setLocation]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          const newTime = prev - 1;
          setTotalElapsed((elapsed) => elapsed + 1);
          
          // Auto advance to next phase when time runs out
          if (newTime === 0) {
            handlePhaseComplete();
          }
          
          return newTime;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  const handlePhaseComplete = () => {
    if (!workout) return;
    
    setIsRunning(false);
    
    if (currentPhase === 'warmup') {
      setCurrentPhase('main');
      const mainTime = (workout.workoutStructure?.mainWork || 25) * 60;
      setTimeLeft(mainTime);
      toast({
        title: "Warm-up Complete!",
        description: "Moving to main workout phase",
      });
    } else if (currentPhase === 'main') {
      setCurrentPhase('cooldown');
      const cooldownTime = (workout.workoutStructure?.coolDown || 5) * 60;
      setTimeLeft(cooldownTime);
      toast({
        title: "Main Workout Complete!",
        description: "Time for cool down",
      });
    } else {
      // Workout complete
      handleWorkoutComplete();
    }
  };

  const handleWorkoutComplete = () => {
    toast({
      title: "Workout Complete!",
      description: "Great job finishing your AI-generated workout!",
    });
    setLocation('/progress');
  };

  const handleStartPause = () => {
    setIsRunning(!isRunning);
  };

  const handleSkipPhase = () => {
    handlePhaseComplete();
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getPhaseTitle = () => {
    switch (currentPhase) {
      case 'warmup': return 'Warm-Up Phase';
      case 'main': return 'Main Training';
      case 'cooldown': return 'Cool Down';
    }
  };

  const getPhaseDescription = () => {
    switch (currentPhase) {
      case 'warmup': return 'Prepare your body for the main workout';
      case 'main': return 'Focus on your training goals and technique';
      case 'cooldown': return 'Help your body recover properly';
    }
  };

  const getProgress = () => {
    if (!workout) return 0;
    
    const totalTime = ((workout.workoutStructure?.warmUp || 10) + 
                      (workout.workoutStructure?.mainWork || 25) + 
                      (workout.workoutStructure?.coolDown || 5)) * 60;
    
    return Math.round((totalElapsed / totalTime) * 100);
  };

  if (!workout) {
    return (
      <div className="container mx-auto p-6 flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading workout...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <div className="space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Brain className="h-6 w-6 text-orange-500" />
            <Badge variant="outline" className="text-orange-600 border-orange-200">
              AI Generated
            </Badge>
          </div>
          <h1 className="text-2xl font-bold text-foreground">{workout.name}</h1>
          <p className="text-muted-foreground">{getPhaseDescription()}</p>
        </div>

        {/* Overall Progress */}
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-sm text-muted-foreground">{getProgress()}%</span>
              </div>
              <Progress value={getProgress()} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Started</span>
                <span>{Math.floor(totalElapsed / 60)} min elapsed</span>
                <span>{workout.estimatedDuration} min total</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Phase */}
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Target className="h-5 w-5 text-orange-600" />
              {getPhaseTitle()}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            {/* Timer */}
            <div className="space-y-2">
              <div className="text-6xl font-bold text-orange-600">
                {formatTime(timeLeft)}
              </div>
              <div className="text-sm text-orange-700 dark:text-orange-300">
                {currentPhase === 'warmup' && 'Get your body ready'}
                {currentPhase === 'main' && 'Train at your target intensity'}
                {currentPhase === 'cooldown' && 'Bring your heart rate down'}
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              <Button
                variant="outline"
                size="lg"
                onClick={handleStartPause}
                className="flex-1 max-w-32"
                data-testid="button-start-pause"
              >
                {isRunning ? (
                  <>
                    <Pause className="h-4 w-4 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Start
                  </>
                )}
              </Button>
              
              <Button
                variant="ghost"
                size="lg"
                onClick={handleSkipPhase}
                className="flex-1 max-w-32"
                data-testid="button-skip-phase"
              >
                <SkipForward className="h-4 w-4 mr-2" />
                Skip
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Phase Navigation */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className={`flex items-center gap-2 ${currentPhase === 'warmup' ? 'text-orange-600' : currentPhase === 'main' || currentPhase === 'cooldown' ? 'text-green-600' : 'text-muted-foreground'}`}>
                <CheckCircle className={`h-4 w-4 ${currentPhase !== 'warmup' ? 'fill-current' : ''}`} />
                <span className="text-sm">Warm-Up</span>
              </div>
              
              <div className={`flex items-center gap-2 ${currentPhase === 'main' ? 'text-orange-600' : currentPhase === 'cooldown' ? 'text-green-600' : 'text-muted-foreground'}`}>
                <CheckCircle className={`h-4 w-4 ${currentPhase === 'cooldown' ? 'fill-current' : ''}`} />
                <span className="text-sm">Main Workout</span>
              </div>
              
              <div className={`flex items-center gap-2 ${currentPhase === 'cooldown' ? 'text-orange-600' : 'text-muted-foreground'}`}>
                <CheckCircle className="h-4 w-4" />
                <span className="text-sm">Cool Down</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            onClick={() => setLocation(`/ai-workouts/${workout.id}`)}
            className="flex-1"
            data-testid="button-back-to-detail"
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Details
          </Button>
          
          <Button 
            variant="destructive" 
            onClick={handleWorkoutComplete}
            className="flex-1"
            data-testid="button-finish-workout"
          >
            <Trophy className="h-4 w-4 mr-2" />
            Finish Workout
          </Button>
        </div>
      </div>
    </div>
  );
}