import {
  users,
  workoutCategories,
  workouts,
  exercises,
  workoutSessions,
  exercisePerformance,
  achievements,
  userAchievements,
  userStats,
  wearableDevices,
  wearableData,
  exerciseCategories,
  exerciseTags,
  exercisesEnhanced,
  userWorkoutPreferences,
  workoutVideos,
  aiWorkoutTemplates,
  type User,
  type UpsertUser,
  type WorkoutCategory,
  type Workout,
  type Exercise,
  type WorkoutSession,
  type ExercisePerformance,
  type Achievement,
  type UserAchievement,
  type UserStats,
  type WearableDevice,
  type WearableData,
  type ExerciseCategory,
  type ExerciseTag,
  type ExerciseEnhanced,
  type UserWorkoutPreferences,
  type WorkoutVideo,
  type AiWorkoutTemplate,
  type InsertWorkoutCategory,
  type InsertWorkout,
  type InsertExercise,
  type InsertWorkoutSession,
  type InsertExercisePerformance,
  type InsertAchievement,
  type InsertUserAchievement,
  type InsertUserStats,
  type InsertWearableDevice,
  type InsertWearableData,
  type InsertExerciseCategory,
  type InsertExerciseTag,
  type InsertExerciseEnhanced,
  type InsertUserWorkoutPreferences,
  type InsertWorkoutVideo,
  type InsertAiWorkoutTemplate,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sum, count, avg, gte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Workout operations
  getWorkoutCategories(): Promise<WorkoutCategory[]>;
  createWorkoutCategory(category: InsertWorkoutCategory): Promise<WorkoutCategory>;
  getWorkoutsByCategory(categoryId: string): Promise<Workout[]>;
  getWorkout(id: string): Promise<(Workout & { category: WorkoutCategory; exercises: Exercise[] }) | undefined>;
  getAllWorkouts(): Promise<Workout[]>;
  getFeaturedWorkouts(): Promise<Workout[]>;
  createWorkout(workout: InsertWorkout): Promise<Workout>;
  
  // Exercise operations
  getExercisesByWorkout(workoutId: string): Promise<Exercise[]>;
  createExercise(exercise: InsertExercise): Promise<Exercise>;
  
  // Session operations
  createWorkoutSession(session: InsertWorkoutSession): Promise<WorkoutSession>;
  updateWorkoutSession(id: string, updates: Partial<WorkoutSession>): Promise<WorkoutSession | undefined>;
  getActiveSession(userId: string): Promise<WorkoutSession | undefined>;
  getRecentSessions(userId: string, limit?: number): Promise<(WorkoutSession & { workout: Workout })[]>;
  
  // Performance tracking
  recordExercisePerformance(performance: InsertExercisePerformance): Promise<ExercisePerformance>;
  updateExercisePerformance(id: string, updates: Partial<ExercisePerformance>): Promise<ExercisePerformance | undefined>;
  
  // Stats operations
  getUserStats(userId: string): Promise<UserStats | undefined>;
  updateUserStats(userId: string, stats: Partial<UserStats>): Promise<UserStats>;
  
  // Achievement operations
  getAchievements(): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  getUserAchievements(userId: string): Promise<(UserAchievement & { achievement: Achievement })[]>;
  awardAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  
  // Analytics
  getWeeklyProgress(userId: string): Promise<{ date: string; workouts: number; duration: number }[]>;
  getShootingStats(userId: string): Promise<{ freeThrowPercentage: number; threePointPercentage: number }>;

  // === ENHANCED FEATURES ===
  
  // Wearable device operations
  getUserWearableDevices(userId: string): Promise<WearableDevice[]>;
  addWearableDevice(device: InsertWearableDevice): Promise<WearableDevice>;
  updateWearableDevice(id: string, updates: Partial<WearableDevice>): Promise<WearableDevice | undefined>;
  deleteWearableDevice(id: string): Promise<boolean>;
  syncWearableData(data: InsertWearableData): Promise<WearableData>;
  getWearableDataForSession(sessionId: string): Promise<WearableData[]>;
  
  // Enhanced exercise categorization
  getExerciseCategories(): Promise<ExerciseCategory[]>;
  createExerciseCategory(category: InsertExerciseCategory): Promise<ExerciseCategory>;
  getExerciseTags(): Promise<ExerciseTag[]>;
  createExerciseTag(tag: InsertExerciseTag): Promise<ExerciseTag>;
  
  // Enhanced exercises
  getEnhancedExercises(): Promise<ExerciseEnhanced[]>;
  getEnhancedExercisesByCategory(categoryId: string): Promise<ExerciseEnhanced[]>;
  createEnhancedExercise(exercise: InsertExerciseEnhanced): Promise<ExerciseEnhanced>;
  searchExercises(query: string): Promise<ExerciseEnhanced[]>;
  
  // User workout preferences and AI personalization
  getUserWorkoutPreferences(userId: string): Promise<UserWorkoutPreferences | undefined>;
  createOrUpdateUserWorkoutPreferences(preferences: InsertUserWorkoutPreferences): Promise<UserWorkoutPreferences>;
  
  // AI workout generation
  getAiWorkoutTemplates(): Promise<AiWorkoutTemplate[]>;
  getAiWorkoutTemplatesByDifficulty(difficulty: string): Promise<AiWorkoutTemplate[]>;
  createAiWorkoutTemplate(template: InsertAiWorkoutTemplate): Promise<AiWorkoutTemplate>;
  generatePersonalizedWorkout(userId: string): Promise<AiWorkoutTemplate | undefined>;
  
  // Future video integration
  uploadWorkoutVideo(video: InsertWorkoutVideo): Promise<WorkoutVideo>;
  getWorkoutVideos(sessionId: string): Promise<WorkoutVideo[]>;
  updateVideoAnalysis(videoId: string, analysis: Partial<WorkoutVideo>): Promise<WorkoutVideo | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Workout operations
  async getWorkoutCategories(): Promise<WorkoutCategory[]> {
    return db.select().from(workoutCategories);
  }

  async createWorkoutCategory(category: InsertWorkoutCategory): Promise<WorkoutCategory> {
    const [newCategory] = await db.insert(workoutCategories).values(category).returning();
    return newCategory;
  }

  async getWorkoutsByCategory(categoryId: string): Promise<Workout[]> {
    return db.select().from(workouts).where(eq(workouts.categoryId, categoryId));
  }

  async getWorkout(id: string): Promise<(Workout & { category: WorkoutCategory; exercises: Exercise[] }) | undefined> {
    const [workout] = await db
      .select({
        id: workouts.id,
        name: workouts.name,
        description: workouts.description,
        categoryId: workouts.categoryId,
        duration: workouts.duration,
        difficulty: workouts.difficulty,
        imageUrl: workouts.imageUrl,
        isPopular: workouts.isPopular,
        createdAt: workouts.createdAt,
        category: workoutCategories,
      })
      .from(workouts)
      .innerJoin(workoutCategories, eq(workouts.categoryId, workoutCategories.id))
      .where(eq(workouts.id, id));

    if (!workout) return undefined;

    const exercisesList = await db
      .select()
      .from(exercises)
      .where(eq(exercises.workoutId, id))
      .orderBy(exercises.order);

    return {
      ...workout,
      exercises: exercisesList,
    };
  }

  async getAllWorkouts(): Promise<Workout[]> {
    return db.select().from(workouts);
  }

  async getFeaturedWorkouts(): Promise<Workout[]> {
    return db.select().from(workouts).where(eq(workouts.isPopular, true)).limit(6);
  }

  async createWorkout(workout: InsertWorkout): Promise<Workout> {
    const [newWorkout] = await db.insert(workouts).values(workout).returning();
    return newWorkout;
  }

  // Exercise operations
  async getExercisesByWorkout(workoutId: string): Promise<Exercise[]> {
    return db
      .select()
      .from(exercises)
      .where(eq(exercises.workoutId, workoutId))
      .orderBy(exercises.order);
  }

  async createExercise(exercise: InsertExercise): Promise<Exercise> {
    const [newExercise] = await db.insert(exercises).values(exercise).returning();
    return newExercise;
  }

  // Session operations
  async createWorkoutSession(session: InsertWorkoutSession): Promise<WorkoutSession> {
    const [newSession] = await db.insert(workoutSessions).values(session).returning();
    return newSession;
  }

  async updateWorkoutSession(id: string, updates: Partial<WorkoutSession>): Promise<WorkoutSession | undefined> {
    const [updated] = await db
      .update(workoutSessions)
      .set(updates)
      .where(eq(workoutSessions.id, id))
      .returning();
    return updated;
  }

  async getActiveSession(userId: string): Promise<WorkoutSession | undefined> {
    const [session] = await db
      .select()
      .from(workoutSessions)
      .where(and(eq(workoutSessions.userId, userId), eq(workoutSessions.status, "in_progress")));
    return session;
  }

  async getRecentSessions(userId: string, limit = 10): Promise<(WorkoutSession & { workout: Workout })[]> {
    return db
      .select({
        id: workoutSessions.id,
        userId: workoutSessions.userId,
        workoutId: workoutSessions.workoutId,
        startedAt: workoutSessions.startedAt,
        completedAt: workoutSessions.completedAt,
        totalDuration: workoutSessions.totalDuration,
        status: workoutSessions.status,
        workout: workouts,
      })
      .from(workoutSessions)
      .innerJoin(workouts, eq(workoutSessions.workoutId, workouts.id))
      .where(eq(workoutSessions.userId, userId))
      .orderBy(desc(workoutSessions.startedAt))
      .limit(limit);
  }

  // Performance tracking
  async recordExercisePerformance(performance: InsertExercisePerformance): Promise<ExercisePerformance> {
    const [newPerformance] = await db.insert(exercisePerformance).values(performance).returning();
    return newPerformance;
  }

  async updateExercisePerformance(id: string, updates: Partial<ExercisePerformance>): Promise<ExercisePerformance | undefined> {
    const [updated] = await db
      .update(exercisePerformance)
      .set(updates)
      .where(eq(exercisePerformance.id, id))
      .returning();
    return updated;
  }

  // Stats operations
  async getUserStats(userId: string): Promise<UserStats | undefined> {
    const [stats] = await db
      .select()
      .from(userStats)
      .where(eq(userStats.userId, userId))
      .orderBy(desc(userStats.date))
      .limit(1);
    return stats;
  }

  async updateUserStats(userId: string, statsUpdate: Partial<UserStats>): Promise<UserStats> {
    const existingStats = await this.getUserStats(userId);
    
    if (existingStats) {
      const [updated] = await db
        .update(userStats)
        .set(statsUpdate)
        .where(eq(userStats.id, existingStats.id))
        .returning();
      return updated;
    } else {
      const [newStats] = await db
        .insert(userStats)
        .values({ userId, ...statsUpdate })
        .returning();
      return newStats;
    }
  }

  // Achievement operations
  async getAchievements(): Promise<Achievement[]> {
    return db.select().from(achievements);
  }

  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [newAchievement] = await db.insert(achievements).values(achievement).returning();
    return newAchievement;
  }

  async getUserAchievements(userId: string): Promise<(UserAchievement & { achievement: Achievement })[]> {
    return db
      .select({
        id: userAchievements.id,
        userId: userAchievements.userId,
        achievementId: userAchievements.achievementId,
        earnedAt: userAchievements.earnedAt,
        progress: userAchievements.progress,
        achievement: achievements,
      })
      .from(userAchievements)
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id))
      .where(eq(userAchievements.userId, userId))
      .orderBy(desc(userAchievements.earnedAt));
  }

  async awardAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const [awarded] = await db.insert(userAchievements).values(userAchievement).returning();
    return awarded;
  }

  // Analytics
  async getWeeklyProgress(userId: string): Promise<{ date: string; workouts: number; duration: number }[]> {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const results = await db
      .select({
        date: sql<string>`DATE(${workoutSessions.startedAt})`,
        workouts: count(workoutSessions.id),
        duration: sum(workoutSessions.totalDuration),
      })
      .from(workoutSessions)
      .where(and(
        eq(workoutSessions.userId, userId),
        eq(workoutSessions.status, "completed"),
        gte(workoutSessions.startedAt, sevenDaysAgo)
      ))
      .groupBy(sql`DATE(${workoutSessions.startedAt})`);

    return results.map(r => ({
      date: r.date,
      workouts: Number(r.workouts) || 0,
      duration: Number(r.duration) || 0,
    }));
  }

  async getShootingStats(userId: string): Promise<{ freeThrowPercentage: number; threePointPercentage: number }> {
    const [stats] = await db
      .select({
        freeThrowsAttempted: sum(userStats.freeThrowsAttempted),
        freeThrowsMade: sum(userStats.freeThrowsMade),
        threePointsAttempted: sum(userStats.threePointsAttempted),
        threePointsMade: sum(userStats.threePointsMade),
      })
      .from(userStats)
      .where(eq(userStats.userId, userId));

    const freeThrowPercentage = stats?.freeThrowsAttempted ? 
      (Number(stats.freeThrowsMade) / Number(stats.freeThrowsAttempted)) * 100 : 0;
    
    const threePointPercentage = stats?.threePointsAttempted ?
      (Number(stats.threePointsMade) / Number(stats.threePointsAttempted)) * 100 : 0;

    return {
      freeThrowPercentage: Math.round(freeThrowPercentage),
      threePointPercentage: Math.round(threePointPercentage),
    };
  }

  // === ENHANCED FEATURES IMPLEMENTATION ===

  // Wearable device operations
  async getUserWearableDevices(userId: string): Promise<WearableDevice[]> {
    return db.select().from(wearableDevices).where(eq(wearableDevices.userId, userId));
  }

  async addWearableDevice(device: InsertWearableDevice): Promise<WearableDevice> {
    const [newDevice] = await db.insert(wearableDevices).values(device).returning();
    return newDevice;
  }

  async updateWearableDevice(id: string, updates: Partial<WearableDevice>): Promise<WearableDevice | undefined> {
    const [updated] = await db
      .update(wearableDevices)
      .set(updates)
      .where(eq(wearableDevices.id, id))
      .returning();
    return updated;
  }

  async deleteWearableDevice(id: string): Promise<boolean> {
    const result = await db.delete(wearableDevices).where(eq(wearableDevices.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async syncWearableData(data: InsertWearableData): Promise<WearableData> {
    const [synced] = await db.insert(wearableData).values(data).returning();
    return synced;
  }

  async getWearableDataForSession(sessionId: string): Promise<WearableData[]> {
    return db.select().from(wearableData).where(eq(wearableData.sessionId, sessionId));
  }

  // Enhanced exercise categorization
  async getExerciseCategories(): Promise<ExerciseCategory[]> {
    return db.select().from(exerciseCategories).where(eq(exerciseCategories.isActive, true));
  }

  async createExerciseCategory(category: InsertExerciseCategory): Promise<ExerciseCategory> {
    const [newCategory] = await db.insert(exerciseCategories).values(category).returning();
    return newCategory;
  }

  async getExerciseTags(): Promise<ExerciseTag[]> {
    return db.select().from(exerciseTags);
  }

  async createExerciseTag(tag: InsertExerciseTag): Promise<ExerciseTag> {
    const [newTag] = await db.insert(exerciseTags).values(tag).returning();
    return newTag;
  }

  // Enhanced exercises
  async getEnhancedExercises(): Promise<ExerciseEnhanced[]> {
    return db.select().from(exercisesEnhanced).where(eq(exercisesEnhanced.isPublic, true));
  }

  async getEnhancedExercisesByCategory(categoryId: string): Promise<ExerciseEnhanced[]> {
    return db.select().from(exercisesEnhanced).where(
      and(
        eq(exercisesEnhanced.categoryId, categoryId),
        eq(exercisesEnhanced.isPublic, true)
      )
    );
  }

  async createEnhancedExercise(exercise: InsertExerciseEnhanced): Promise<ExerciseEnhanced> {
    const [newExercise] = await db.insert(exercisesEnhanced).values(exercise).returning();
    return newExercise;
  }

  async searchExercises(query: string): Promise<ExerciseEnhanced[]> {
    return db.select().from(exercisesEnhanced).where(
      and(
        sql`${exercisesEnhanced.name} ILIKE ${'%' + query + '%'}`,
        eq(exercisesEnhanced.isPublic, true)
      )
    );
  }

  // User workout preferences and AI personalization
  async getUserWorkoutPreferences(userId: string): Promise<UserWorkoutPreferences | undefined> {
    const [preferences] = await db.select().from(userWorkoutPreferences).where(eq(userWorkoutPreferences.userId, userId));
    return preferences;
  }

  async createOrUpdateUserWorkoutPreferences(preferences: InsertUserWorkoutPreferences): Promise<UserWorkoutPreferences> {
    const existing = await this.getUserWorkoutPreferences(preferences.userId);
    
    if (existing) {
      const [updated] = await db
        .update(userWorkoutPreferences)
        .set({ ...preferences, updatedAt: new Date() })
        .where(eq(userWorkoutPreferences.userId, preferences.userId))
        .returning();
      return updated;
    } else {
      const [newPreferences] = await db.insert(userWorkoutPreferences).values(preferences).returning();
      return newPreferences;
    }
  }

  // AI workout generation
  async getAiWorkoutTemplates(): Promise<AiWorkoutTemplate[]> {
    return db.select().from(aiWorkoutTemplates).where(eq(aiWorkoutTemplates.isActive, true));
  }

  async getAiWorkoutTemplatesByDifficulty(difficulty: string): Promise<AiWorkoutTemplate[]> {
    return db.select().from(aiWorkoutTemplates).where(
      and(
        eq(aiWorkoutTemplates.difficulty, difficulty),
        eq(aiWorkoutTemplates.isActive, true)
      )
    );
  }

  async createAiWorkoutTemplate(template: InsertAiWorkoutTemplate): Promise<AiWorkoutTemplate> {
    const [newTemplate] = await db.insert(aiWorkoutTemplates).values(template).returning();
    return newTemplate;
  }

  async generatePersonalizedWorkout(userId: string): Promise<AiWorkoutTemplate | undefined> {
    const preferences = await this.getUserWorkoutPreferences(userId);
    
    if (!preferences) {
      // Return a basic template if no preferences set
      const [template] = await db.select().from(aiWorkoutTemplates).where(
        and(
          eq(aiWorkoutTemplates.difficulty, 'beginner'),
          eq(aiWorkoutTemplates.isActive, true)
        )
      ).limit(1);
      return template;
    }

    // Find templates matching user's skill level and preferences
    const [template] = await db.select().from(aiWorkoutTemplates).where(
      and(
        eq(aiWorkoutTemplates.difficulty, preferences.skillLevel),
        eq(aiWorkoutTemplates.isActive, true)
      )
    ).limit(1);
    
    return template;
  }

  // Future video integration
  async uploadWorkoutVideo(video: InsertWorkoutVideo): Promise<WorkoutVideo> {
    const [newVideo] = await db.insert(workoutVideos).values(video).returning();
    return newVideo;
  }

  async getWorkoutVideos(sessionId: string): Promise<WorkoutVideo[]> {
    return db.select().from(workoutVideos).where(eq(workoutVideos.sessionId, sessionId));
  }

  async updateVideoAnalysis(videoId: string, analysis: Partial<WorkoutVideo>): Promise<WorkoutVideo | undefined> {
    const [updated] = await db
      .update(workoutVideos)
      .set(analysis)
      .where(eq(workoutVideos.id, videoId))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
