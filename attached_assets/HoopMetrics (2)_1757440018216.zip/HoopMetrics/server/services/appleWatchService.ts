import { storage } from "../storage";
import type { InsertWearableDevice, InsertWearableData, WearableDevice } from "@shared/schema";

interface HeartRateReading {
  timestamp: Date;
  value: number;
  source: string;
}

interface HRVReading {
  timestamp: Date;
  value: number;
}

interface WorkoutData {
  id: string;
  type: string;
  startTime: Date;
  endTime: Date;
  duration: number;
  calories?: number;
  averageHeartRate?: number;
  maxHeartRate?: number;
}

interface RecoveryMetrics {
  hrv: number | null;
  restingHeartRate: number | null;
  recoveryScore: number | null;
  timestamp: Date;
}

export class AppleWatchService {
  private isInitialized = false;
  private monitoringCallbacks: Map<string, (heartRate: number) => void> = new Map();
  
  async initialize(): Promise<boolean> {
    try {
      // Mock initialization - in a real app you'd connect to HealthKit
      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error('Apple Watch initialization failed:', error);
      return false;
    }
  }

  async authenticateUser(userId: string, permissions: string[]): Promise<{success: boolean, token?: string, deviceData?: any}> {
    try {
      if (!this.isInitialized) {
        const initialized = await this.initialize();
        if (!initialized) {
          return { success: false };
        }
      }

      // Generate access token
      const accessToken = `healthkit_${userId}_${Date.now()}`;
      
      // Mock device data - in real implementation, get from HealthKit
      const deviceData = {
        deviceType: 'apple_watch' as const,
        deviceModel: 'Apple Watch Series 9',
        deviceId: `apple_watch_${userId}`,
        permissions: permissions,
      };

      // Store device in database
      const deviceRecord: InsertWearableDevice = {
        userId,
        deviceType: deviceData.deviceType,
        deviceModel: deviceData.deviceModel,
        deviceId: deviceData.deviceId,
        accessToken,
        permissions: permissions,
        isActive: true,
      };

      await storage.addWearableDevice(deviceRecord);

      return { 
        success: true, 
        token: accessToken,
        deviceData 
      };
    } catch (error) {
      console.error('Apple Watch authentication failed:', error);
      return { success: false };
    }
  }

  async getHeartRateData(deviceId: string, startDate: Date, endDate: Date): Promise<HeartRateReading[]> {
    try {
      // Mock heart rate data - in real implementation, fetch from HealthKit
      const mockData: HeartRateReading[] = [];
      const timeRange = endDate.getTime() - startDate.getTime();
      const dataPoints = Math.min(50, Math.floor(timeRange / (60 * 1000))); // One per minute max
      
      for (let i = 0; i < dataPoints; i++) {
        const timestamp = new Date(startDate.getTime() + (i * timeRange / dataPoints));
        const baseHR = 140; // Base workout heart rate
        const variation = Math.random() * 40 - 20;
        const heartRate = Math.max(60, Math.min(200, baseHR + variation));
        
        mockData.push({
          timestamp,
          value: Math.round(heartRate),
          source: 'apple_watch'
        });
      }

      return mockData;
    } catch (error) {
      console.error('Failed to get heart rate data:', error);
      return [];
    }
  }

  async getWorkoutData(deviceId: string, startDate: Date, endDate: Date): Promise<WorkoutData[]> {
    try {
      // Mock workout data - in real implementation, fetch from HealthKit
      return [{
        id: `workout_${Date.now()}`,
        type: 'Basketball',
        startTime: startDate,
        endTime: endDate,
        duration: Math.floor((endDate.getTime() - startDate.getTime()) / 1000 / 60), // minutes
        calories: Math.floor(Math.random() * 300 + 200),
        averageHeartRate: Math.floor(Math.random() * 40 + 140),
        maxHeartRate: Math.floor(Math.random() * 20 + 170)
      }];
    } catch (error) {
      console.error('Failed to get workout data:', error);
      return [];
    }
  }

  async getRecoveryMetrics(deviceId: string): Promise<RecoveryMetrics> {
    try {
      // Mock recovery data - in real implementation, calculate from HRV
      const hrv = Math.random() * 30 + 25; // 25-55ms range
      const restingHeartRate = Math.floor(Math.random() * 20 + 50); // 50-70 bpm
      
      return {
        hrv,
        restingHeartRate,
        recoveryScore: this.calculateRecoveryScore(hrv, restingHeartRate),
        timestamp: new Date()
      };
    } catch (error) {
      console.error('Failed to get recovery metrics:', error);
      return {
        hrv: null,
        restingHeartRate: null,
        recoveryScore: null,
        timestamp: new Date()
      };
    }
  }

  private calculateRecoveryScore(hrv: number, restingHR: number): number {
    // Simplified recovery score calculation
    const hrvScore = Math.min(100, (hrv / 50) * 100); // Assuming 50ms is good HRV
    const hrScore = Math.max(0, 100 - ((restingHR - 50) * 2)); // Lower resting HR = better
    
    return Math.round((hrvScore + hrScore) / 2);
  }

  startRealTimeMonitoring(userId: string, sessionId: string, callback: (heartRate: number) => void): void {
    // Store callback for this session
    this.monitoringCallbacks.set(sessionId, callback);
    
    // Start mock real-time monitoring
    const interval = setInterval(() => {
      const baseHR = 140;
      const variation = Math.random() * 40 - 20;
      const currentHR = Math.max(60, Math.min(200, baseHR + variation));
      
      callback(Math.round(currentHR));
    }, 5000); // Every 5 seconds

    // Store interval for cleanup
    (this as any)[`interval_${sessionId}`] = interval;
  }

  stopRealTimeMonitoring(sessionId: string): void {
    // Clean up interval
    const intervalKey = `interval_${sessionId}`;
    if ((this as any)[intervalKey]) {
      clearInterval((this as any)[intervalKey]);
      delete (this as any)[intervalKey];
    }
    
    // Remove callback
    this.monitoringCallbacks.delete(sessionId);
  }

  async syncWorkoutData(userId: string, sessionId: string, deviceId: string): Promise<void> {
    try {
      // Get the session details to determine time range
      const session = await storage.getActiveSession(userId);
      if (!session) return;

      const startTime = session.startedAt || new Date();
      const endTime = new Date();

      // Get heart rate data
      const heartRateData = await this.getHeartRateData(deviceId, startTime, endTime);
      
      // Calculate metrics
      const averageHeartRate = heartRateData.length > 0 
        ? Math.round(heartRateData.reduce((sum, hr) => sum + hr.value, 0) / heartRateData.length)
        : null;
      
      const maxHeartRate = heartRateData.length > 0
        ? Math.max(...heartRateData.map(hr => hr.value))
        : null;
      
      const caloriesBurned = this.calculateCalories(heartRateData, endTime.getTime() - startTime.getTime());
      
      // Store wearable data
      const wearableData: InsertWearableData = {
        deviceId,
        userId,
        sessionId,
        heartRateData: heartRateData,
        caloriesBurned,
        activeCalories: Math.floor(caloriesBurned * 0.8), // Estimate active calories
        effortScore: this.calculateEffortScore(heartRateData),
        recordedAt: startTime,
      };

      await storage.syncWearableData(wearableData);
    } catch (error) {
      console.error('Failed to sync workout data:', error);
    }
  }

  private calculateCalories(heartRateData: HeartRateReading[], durationMs: number): number {
    if (heartRateData.length === 0) return 0;
    
    const averageHR = heartRateData.reduce((sum, hr) => sum + hr.value, 0) / heartRateData.length;
    const durationMinutes = durationMs / (1000 * 60);
    
    // Simplified calorie calculation based on heart rate
    // More sophisticated calculation would consider age, weight, etc.
    const caloriesPerMinute = (averageHR - 60) * 0.1;
    
    return Math.max(0, Math.round(caloriesPerMinute * durationMinutes));
  }

  private calculateEffortScore(heartRateData: HeartRateReading[]): number {
    if (heartRateData.length === 0) return 5;
    
    const averageHR = heartRateData.reduce((sum, hr) => sum + hr.value, 0) / heartRateData.length;
    
    // Convert average heart rate to 1-10 effort score
    if (averageHR < 100) return Math.round(1 + (averageHR - 60) / 10);
    if (averageHR < 140) return Math.round(3 + (averageHR - 100) / 10);
    if (averageHR < 170) return Math.round(6 + (averageHR - 140) / 10);
    return Math.min(10, Math.round(8 + (averageHR - 170) / 15));
  }

  async getUserDevices(userId: string): Promise<WearableDevice[]> {
    try {
      const devices = await storage.getUserWearableDevices(userId);
      return devices.filter(device => device.deviceType === 'apple_watch');
    } catch (error) {
      console.error('Failed to get user Apple Watch devices:', error);
      return [];
    }
  }

  async checkCompatibility(): Promise<boolean> {
    // Mock compatibility check - in real implementation, check for HealthKit availability
    return true;
  }

  async testConnection(token: string): Promise<{success: boolean, data?: any}> {
    try {
      // Mock connection test - in real implementation, make test HealthKit call
      return {
        success: true,
        data: {
          heartRatePermission: true,
          caloriesPermission: true,
          workoutsPermission: true,
          hrvPermission: true
        }
      };
    } catch (error) {
      return { success: false };
    }
  }
}

export const appleWatchService = new AppleWatchService();