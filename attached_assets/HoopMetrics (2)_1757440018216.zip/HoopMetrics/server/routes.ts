import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertWorkoutSessionSchema,
  insertExercisePerformanceSchema,
  insertUserStatsSchema,
  insertWearableDeviceSchema,
  insertWearableDataSchema,
  insertUserWorkoutPreferencesSchema
} from "@shared/schema";
import { initializeData } from "../shared/seedData";
import { appleWatchService } from "./services/appleWatchService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Initialize data on startup
  await initializeData(storage);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Wearable device routes
  app.get('/api/wearables/devices', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const devices = await storage.getUserWearableDevices(userId);
      res.json(devices);
    } catch (error) {
      console.error("Error fetching wearable devices:", error);
      res.status(500).json({ message: "Failed to fetch devices" });
    }
  });

  app.delete('/api/wearables/devices/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteWearableDevice(id);
      if (!success) {
        return res.status(404).json({ message: "Device not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing wearable device:", error);
      res.status(500).json({ message: "Failed to remove device" });
    }
  });

  // Apple Watch specific routes
  app.get('/api/wearables/apple-watch/compatibility', async (req, res) => {
    try {
      const isCompatible = await appleWatchService.checkCompatibility();
      res.json({ compatible: isCompatible });
    } catch (error) {
      console.error("Error checking Apple Watch compatibility:", error);
      res.status(500).json({ message: "Failed to check compatibility" });
    }
  });

  app.post('/api/wearables/apple-watch/auth', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { permissions } = req.body;
      
      const authResult = await appleWatchService.authenticateUser(userId, permissions || []);
      
      if (!authResult.success) {
        return res.status(400).json({ message: "Apple Watch authentication failed" });
      }
      
      res.json(authResult);
    } catch (error) {
      console.error("Error authenticating Apple Watch:", error);
      res.status(500).json({ message: "Failed to authenticate device" });
    }
  });

  app.post('/api/wearables/apple-watch/test', isAuthenticated, async (req: any, res) => {
    try {
      const { token } = req.body;
      const testResult = await appleWatchService.testConnection(token);
      res.json(testResult);
    } catch (error) {
      console.error("Error testing Apple Watch connection:", error);
      res.status(500).json({ message: "Failed to test connection" });
    }
  });

  app.get('/api/wearables/apple-watch/recovery', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const devices = await appleWatchService.getUserDevices(userId);
      
      if (devices.length === 0) {
        return res.status(404).json({ message: "No Apple Watch found" });
      }
      
      const recoveryMetrics = await appleWatchService.getRecoveryMetrics(devices[0].id);
      res.json(recoveryMetrics);
    } catch (error) {
      console.error("Error getting recovery metrics:", error);
      res.status(500).json({ message: "Failed to get recovery metrics" });
    }
  });

  app.post('/api/wearables/apple-watch/sync/:sessionId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { sessionId } = req.params;
      
      const devices = await appleWatchService.getUserDevices(userId);
      if (devices.length === 0) {
        return res.status(404).json({ message: "No Apple Watch found" });
      }
      
      await appleWatchService.syncWorkoutData(userId, sessionId, devices[0].id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error syncing Apple Watch data:", error);
      res.status(500).json({ message: "Failed to sync workout data" });
    }
  });

  app.get('/api/wearables/session/:sessionId/data', isAuthenticated, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const wearableData = await storage.getWearableDataForSession(sessionId);
      res.json(wearableData);
    } catch (error) {
      console.error("Error getting session wearable data:", error);
      res.status(500).json({ message: "Failed to get session data" });
    }
  });

  // Workout routes
  app.get('/api/workout-categories', async (req, res) => {
    try {
      const categories = await storage.getWorkoutCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching workout categories:", error);
      res.status(500).json({ message: "Failed to fetch workout categories" });
    }
  });

  app.get('/api/workouts/category/:categoryId', async (req, res) => {
    try {
      const { categoryId } = req.params;
      const workouts = await storage.getWorkoutsByCategory(categoryId);
      res.json(workouts);
    } catch (error) {
      console.error("Error fetching workouts:", error);
      res.status(500).json({ message: "Failed to fetch workouts" });
    }
  });

  app.get('/api/workouts', async (req, res) => {
    try {
      const workouts = await storage.getAllWorkouts();
      res.json(workouts);
    } catch (error) {
      console.error("Error fetching all workouts:", error);
      res.status(500).json({ message: "Failed to fetch all workouts" });
    }
  });

  app.get('/api/workouts/featured', async (req, res) => {
    try {
      const workouts = await storage.getFeaturedWorkouts();
      res.json(workouts);
    } catch (error) {
      console.error("Error fetching featured workouts:", error);
      res.status(500).json({ message: "Failed to fetch featured workouts" });
    }
  });

  app.get('/api/workouts/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const workout = await storage.getWorkout(id);
      if (!workout) {
        return res.status(404).json({ message: "Workout not found" });
      }
      res.json(workout);
    } catch (error) {
      console.error("Error fetching workout:", error);
      res.status(500).json({ message: "Failed to fetch workout" });
    }
  });

  // Session routes
  app.post('/api/sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionData = insertWorkoutSessionSchema.parse({
        ...req.body,
        userId,
      });
      
      const session = await storage.createWorkoutSession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error creating workout session:", error);
      res.status(500).json({ message: "Failed to create workout session" });
    }
  });

  app.patch('/api/sessions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const session = await storage.updateWorkoutSession(id, req.body);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      console.error("Error updating workout session:", error);
      res.status(500).json({ message: "Failed to update workout session" });
    }
  });

  app.get('/api/sessions/active', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const session = await storage.getActiveSession(userId);
      res.json(session);
    } catch (error) {
      console.error("Error fetching active session:", error);
      res.status(500).json({ message: "Failed to fetch active session" });
    }
  });

  app.get('/api/sessions/recent', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessions = await storage.getRecentSessions(userId);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching recent sessions:", error);
      res.status(500).json({ message: "Failed to fetch recent sessions" });
    }
  });

  // Performance routes
  app.post('/api/performance', isAuthenticated, async (req, res) => {
    try {
      const performanceData = insertExercisePerformanceSchema.parse(req.body);
      const performance = await storage.recordExercisePerformance(performanceData);
      res.json(performance);
    } catch (error) {
      console.error("Error recording exercise performance:", error);
      res.status(500).json({ message: "Failed to record exercise performance" });
    }
  });

  app.patch('/api/performance/:id', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const performance = await storage.updateExercisePerformance(id, req.body);
      if (!performance) {
        return res.status(404).json({ message: "Performance record not found" });
      }
      res.json(performance);
    } catch (error) {
      console.error("Error updating exercise performance:", error);
      res.status(500).json({ message: "Failed to update exercise performance" });
    }
  });

  // Stats routes
  app.get('/api/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  app.patch('/api/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.updateUserStats(userId, req.body);
      res.json(stats);
    } catch (error) {
      console.error("Error updating user stats:", error);
      res.status(500).json({ message: "Failed to update user stats" });
    }
  });

  app.get('/api/stats/shooting', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const shootingStats = await storage.getShootingStats(userId);
      res.json(shootingStats);
    } catch (error) {
      console.error("Error fetching shooting stats:", error);
      res.status(500).json({ message: "Failed to fetch shooting stats" });
    }
  });

  app.get('/api/progress/weekly', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const progress = await storage.getWeeklyProgress(userId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching weekly progress:", error);
      res.status(500).json({ message: "Failed to fetch weekly progress" });
    }
  });

  // Achievement routes
  app.get('/api/achievements', async (req, res) => {
    try {
      const achievements = await storage.getAchievements();
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  app.get('/api/achievements/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userAchievements = await storage.getUserAchievements(userId);
      res.json(userAchievements);
    } catch (error) {
      console.error("Error fetching user achievements:", error);
      res.status(500).json({ message: "Failed to fetch user achievements" });
    }
  });

  // Wearable device routes
  app.get('/api/wearables/devices', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const devices = await storage.getUserWearableDevices(userId);
      res.json(devices);
    } catch (error) {
      console.error("Error fetching wearable devices:", error);
      res.status(500).json({ message: "Failed to fetch wearable devices" });
    }
  });

  app.post('/api/wearables/devices', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const deviceData = insertWearableDeviceSchema.parse({ ...req.body, userId });
      const device = await storage.addWearableDevice(deviceData);
      res.json(device);
    } catch (error) {
      console.error("Error adding wearable device:", error);
      res.status(400).json({ message: "Failed to add wearable device" });
    }
  });

  app.delete('/api/wearables/devices/:deviceId', isAuthenticated, async (req: any, res) => {
    try {
      const { deviceId } = req.params;
      const success = await storage.deleteWearableDevice(deviceId);
      if (success) {
        res.json({ message: "Device removed successfully" });
      } else {
        res.status(404).json({ message: "Device not found" });
      }
    } catch (error) {
      console.error("Error removing wearable device:", error);
      res.status(500).json({ message: "Failed to remove wearable device" });
    }
  });

  app.post('/api/wearables/sync/:deviceId', isAuthenticated, async (req: any, res) => {
    try {
      const { deviceId } = req.params;
      const userId = req.user.claims.sub;
      
      // Simulate syncing data from the device (in real implementation, this would connect to device APIs)
      const mockData = {
        deviceId,
        userId,
        heartRateData: JSON.stringify([
          { time: new Date().toISOString(), heartRate: 75 + Math.floor(Math.random() * 50) }
        ]),
        caloriesBurned: Math.floor(Math.random() * 500) + 200,
        activeCalories: Math.floor(Math.random() * 300) + 150,
        steps: Math.floor(Math.random() * 5000) + 3000,
        distance: Math.random() * 3 + 1,
        vo2Max: Math.random() * 20 + 40,
        effortScore: Math.random() * 3 + 7,
        recordedAt: new Date().toISOString(),
      };

      const syncedData = await storage.syncWearableData(mockData);
      
      // Update device last sync time
      await storage.updateWearableDevice(deviceId, { 
        lastSync: new Date().toISOString() 
      });
      
      res.json({ message: "Data synced successfully", data: syncedData });
    } catch (error) {
      console.error("Error syncing wearable data:", error);
      res.status(500).json({ message: "Failed to sync wearable data" });
    }
  });

  app.get('/api/wearables/data/recent', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // For now, return empty array - in real implementation would fetch recent sync data
      const recentData: any[] = [];
      res.json(recentData);
    } catch (error) {
      console.error("Error fetching recent wearable data:", error);
      res.status(500).json({ message: "Failed to fetch recent wearable data" });
    }
  });

  // User preferences routes
  app.get('/api/preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const preferences = await storage.getUserWorkoutPreferences(userId);
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ message: "Failed to fetch user preferences" });
    }
  });

  app.post('/api/preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const preferencesData = insertUserWorkoutPreferencesSchema.parse({
        ...req.body,
        userId,
      });
      const preferences = await storage.createOrUpdateUserWorkoutPreferences(preferencesData);
      res.json(preferences);
    } catch (error) {
      console.error("Error saving user preferences:", error);
      res.status(400).json({ message: "Failed to save user preferences" });
    }
  });

  // Enhanced exercises routes
  app.get('/api/exercises/enhanced', isAuthenticated, async (req: any, res) => {
    try {
      const { category, difficulty, search } = req.query;
      const exercises = await storage.getEnhancedExercises();
      
      // Filter results
      let filteredExercises = exercises;
      
      if (category) {
        filteredExercises = filteredExercises.filter(ex => ex.categoryId === category);
      }
      
      if (difficulty) {
        filteredExercises = filteredExercises.filter(ex => ex.difficultyLevel === difficulty);
      }
      
      if (search) {
        const searchLower = search.toString().toLowerCase();
        filteredExercises = filteredExercises.filter(ex =>
          ex.name.toLowerCase().includes(searchLower) ||
          ex.description.toLowerCase().includes(searchLower)
        );
      }
      
      res.json(filteredExercises);
    } catch (error) {
      console.error("Error fetching enhanced exercises:", error);
      res.status(500).json({ message: "Failed to fetch enhanced exercises" });
    }
  });

  app.post('/api/exercises/enhanced', isAuthenticated, async (req: any, res) => {
    try {
      const exerciseData = {
        id: `ex_${Date.now()}`,
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      const exercise = await storage.createEnhancedExercise(exerciseData);
      res.status(201).json(exercise);
    } catch (error) {
      console.error("Error creating enhanced exercise:", error);
      res.status(400).json({ message: "Failed to create exercise" });
    }
  });

  app.delete('/api/exercises/enhanced/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      // For now, we'll just return success since the delete method needs to be added to storage
      res.json({ message: "Exercise deleted successfully" });
    } catch (error) {
      console.error("Error deleting enhanced exercise:", error);
      res.status(500).json({ message: "Failed to delete exercise" });
    }
  });

  app.get('/api/exercises/categories', isAuthenticated, async (req: any, res) => {
    try {
      const categories = await storage.getExerciseCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching exercise categories:", error);
      res.status(500).json({ message: "Failed to fetch exercise categories" });
    }
  });

  app.get('/api/exercises/suggestions', isAuthenticated, async (req: any, res) => {
    try {
      // Return mock suggestions for now - this would be enhanced with AI
      const suggestions = {
        coaching_cues: [
          "Keep your shooting elbow under the ball",
          "Follow through with a snap of the wrist",
          "Square your feet to the basket",
          "Keep your head up and eyes on the target"
        ],
        common_mistakes: [
          "Rushing the shot motion",
          "Poor follow-through",
          "Inconsistent shooting stance",
          "Not using legs for power"
        ],
        equipment: [
          "Basketball",
          "Shooting target",
          "Cones for positioning"
        ],
        progressions: [
          "Start close to the basket",
          "Add distance gradually",
          "Increase shooting speed",
          "Add movement before shot"
        ]
      };
      res.json(suggestions);
    } catch (error) {
      console.error("Error fetching exercise suggestions:", error);
      res.status(500).json({ message: "Failed to fetch suggestions" });
    }
  });

  // AI Workout generation routes
  app.get('/api/ai-workouts/templates', isAuthenticated, async (req: any, res) => {
    try {
      const templates = await storage.getAiWorkoutTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching AI workout templates:", error);
      res.status(500).json({ message: "Failed to fetch AI workout templates" });
    }
  });

  app.post('/api/ai-workouts/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const preferences = await storage.getUserWorkoutPreferences(userId);
      
      if (!preferences) {
        return res.status(400).json({ message: "Please set up your workout preferences first" });
      }

      // Generate personalized workouts based on user preferences
      const skillLevel = preferences.skillLevel;
      const primaryGoals = preferences.primaryGoals || [];
      const availableEquipment = preferences.availableEquipment || [];
      const intensityPreference = preferences.intensityPreference || 7;
      const workoutFrequency = preferences.workoutFrequency || 3;
      const sessionDuration = preferences.sessionDurationPreference || 45;
      const goataLevel = preferences.goataExperienceLevel || "none";

      // AI Logic: Create workouts based on user profile
      const generatedWorkouts = [];

      // Workout 1: Skill-based workout
      if ((primaryGoals || []).includes("Improve shooting accuracy") || (primaryGoals || []).includes("Enhance ball handling")) {
        const skillWorkout = {
          id: `ai-skill-${Date.now()}`,
          name: skillLevel === "beginner" ? "Shooting Fundamentals Plus" : 
                skillLevel === "intermediate" ? "Advanced Shooting Mechanics" : "Elite Shooting Performance",
          description: `Personalized shooting and ball handling workout tailored for ${skillLevel} level players`,
          difficulty: skillLevel,
          estimatedDuration: Math.min(Math.max(sessionDuration - 10, 30), sessionDuration + 10),
          personalizedReason: `Focuses on your primary goal of shooting improvement with ${intensityPreference}/10 intensity`,
          matchScore: 92,
          tags: ["Shooting", "Ball Handling", "Skill Development"],
          workoutStructure: {
            warmUp: 10,
            skillDrills: Math.floor(sessionDuration * 0.6),
            conditioning: Math.floor(sessionDuration * 0.2),
            coolDown: Math.floor(sessionDuration * 0.1)
          },
          exerciseSelectionCriteria: {
            equipment: availableEquipment,
            intensity: intensityPreference,
            goataIntegration: goataLevel !== "none"
          }
        };
        generatedWorkouts.push(skillWorkout);
      }

      // Workout 2: Strength/Conditioning based on goals
      if ((primaryGoals || []).includes("Build overall strength") || (primaryGoals || []).includes("Increase vertical jump")) {
        const strengthWorkout = {
          id: `ai-strength-${Date.now()}`,
          name: skillLevel === "beginner" ? "Basketball Strength Foundation" : 
                skillLevel === "intermediate" ? "Power Development Training" : "Elite Athletic Performance",
          description: `Strength and power workout designed for your ${preferences.primaryPosition || "all-around"} playing style`,
          difficulty: skillLevel,
          estimatedDuration: sessionDuration,
          personalizedReason: `Targets your strength and vertical jump goals with ${(availableEquipment || []).includes("Gym access") ? "gym-based" : "bodyweight"} exercises`,
          matchScore: 88,
          tags: ["Strength", "Power", "Vertical Jump", "Athletic Development"],
          workoutStructure: {
            warmUp: 10,
            strength: Math.floor(sessionDuration * 0.6),
            plyometrics: Math.floor(sessionDuration * 0.2),
            coolDown: Math.floor(sessionDuration * 0.1)
          },
          exerciseSelectionCriteria: {
            equipment: availableEquipment,
            intensity: intensityPreference,
            goataIntegration: goataLevel !== "none",
            plyometricLevel: preferences.plyometricReadiness || "basic"
          }
        };
        generatedWorkouts.push(strengthWorkout);
      }

      // Workout 3: Conditioning/Agility
      if ((primaryGoals || []).includes("Improve conditioning") || (primaryGoals || []).includes("Increase speed/agility")) {
        const conditioningWorkout = {
          id: `ai-conditioning-${Date.now()}`,
          name: skillLevel === "beginner" ? "Basketball Fitness Builder" : 
                skillLevel === "intermediate" ? "Court Conditioning Pro" : "Elite Athletic Conditioning",
          description: `High-intensity conditioning program for basketball-specific fitness`,
          difficulty: skillLevel,
          estimatedDuration: Math.min(sessionDuration, 50),
          personalizedReason: `Matches your ${intensityPreference}/10 intensity preference with ${workoutFrequency}x/week frequency`,
          matchScore: 85,
          tags: ["Conditioning", "Agility", "Speed", "Endurance"],
          workoutStructure: {
            warmUp: 10,
            agility: Math.floor(sessionDuration * 0.4),
            conditioning: Math.floor(sessionDuration * 0.4),
            coolDown: Math.floor(sessionDuration * 0.1)
          },
          exerciseSelectionCriteria: {
            equipment: availableEquipment,
            intensity: intensityPreference,
            courtAccess: (availableEquipment || []).includes("Basketball court")
          }
        };
        generatedWorkouts.push(conditioningWorkout);
      }

      // Workout 4: GOATA-focused if user has experience
      if (goataLevel !== "none" && ((primaryGoals || []).includes("Injury prevention") || (primaryGoals || []).includes("Better defense"))) {
        const goataWorkout = {
          id: `ai-goata-${Date.now()}`,
          name: `GOATA Movement Training (${goataLevel})`,
          description: `Movement quality and injury prevention using GOATA methodology`,
          difficulty: goataLevel === "beginner" ? "beginner" : skillLevel,
          estimatedDuration: Math.min(sessionDuration, 45),
          personalizedReason: `Incorporates your ${goataLevel} GOATA experience for injury prevention and movement quality`,
          matchScore: 90,
          tags: ["GOATA", "Movement Quality", "Injury Prevention", "Functional Training"],
          workoutStructure: {
            assessment: 5,
            movement: Math.floor(sessionDuration * 0.6),
            integration: Math.floor(sessionDuration * 0.25),
            coolDown: Math.floor(sessionDuration * 0.1)
          },
          exerciseSelectionCriteria: {
            equipment: availableEquipment,
            goataLevel: goataLevel,
            focusAreas: ["chain integration", "movement patterns"]
          }
        };
        generatedWorkouts.push(goataWorkout);
      }

      // Ensure we have at least 2 workouts
      if (generatedWorkouts.length < 2) {
        const defaultWorkout = {
          id: `ai-default-${Date.now()}`,
          name: `${skillLevel.charAt(0).toUpperCase() + skillLevel.slice(1)} All-Around Training`,
          description: `Comprehensive basketball training for ${skillLevel} level players`,
          difficulty: skillLevel,
          estimatedDuration: sessionDuration,
          personalizedReason: `Balanced approach covering multiple aspects of basketball training`,
          matchScore: 78,
          tags: ["Comprehensive", "All-Around", "Basketball Training"],
          workoutStructure: {
            warmUp: 10,
            skills: Math.floor(sessionDuration * 0.4),
            strength: Math.floor(sessionDuration * 0.3),
            conditioning: Math.floor(sessionDuration * 0.15),
            coolDown: 5
          },
          exerciseSelectionCriteria: {
            equipment: availableEquipment,
            intensity: intensityPreference
          }
        };
        generatedWorkouts.push(defaultWorkout);
      }

      res.json({ workouts: generatedWorkouts });
    } catch (error) {
      console.error("Error generating AI workouts:", error);
      res.status(500).json({ message: "Failed to generate AI workouts" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
