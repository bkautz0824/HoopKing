# CourtFit Basketball Training Application

## Overview

CourtFit is an AI-powered basketball training application designed to enhance user skills through structured workout programs, progress tracking, achievement systems, and wearable device integration. It offers professional workout plans for gym and court, real-time analytics, personalized AI workout generation, and advanced biometric monitoring. The system supports user authentication, workout session management, progress visualization, and integrates with wearable devices for in-depth training insights. Its business vision is to provide a comprehensive, personalized training experience that helps basketball enthusiasts improve their game efficiently and effectively.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

CourtFit utilizes a full-stack architecture with a clear separation between client and server. The frontend is built with React and TypeScript, using Vite for building, while the backend is an Express.js application also in TypeScript. The project adopts a monorepo structure, sharing types and schemas.

**Frontend:**
-   **Framework & Language:** React with TypeScript.
-   **Routing:** Wouter for lightweight client-side routing.
-   **State Management:** TanStack React Query for server state management.
-   **UI Components:** shadcn/ui built on Radix UI primitives for accessibility and customization.
-   **Styling:** Tailwind CSS with CSS custom properties for consistent theming.
-   **Real-time Features:** Implements real-time heart rate monitoring and workout session updates.

**Backend:**
-   **Framework:** Express.js with a RESTful API design.
-   **Organization:** Centralized route registration and modular endpoint definitions.
-   **Data Access:** Storage interface pattern for database operations.
-   **Middleware:** Includes request logging, error handling, and authentication.
-   **Services:** Dedicated service layer for wearable device integration (Apple Watch, Garmin, Coros).

**Database:**
-   **Technology:** PostgreSQL with Drizzle ORM for type-safe operations.
-   **Schema:** Centralized schema definitions with Zod validation.
-   **Data Model:** Supports user management, workout categories, exercises, sessions, performance tracking, wearable device data, AI workout templates, and enhanced exercise categorization.
-   **Sessions:** Integrates with `connect-pg-simple` for secure session management.
-   **Migrations:** Uses Drizzle Kit for schema migrations.

**Authentication:**
-   **Method:** Replit OAuth integration using OpenID Connect (OIDC).
-   **Session Management:** PostgreSQL-backed sessions with secure cookie settings.
-   **User Management:** Automatic user creation and profile synchronization with Replit user data.
-   **Security:** Middleware-based route protection.

**Wearable Device Integration:**
-   Comprehensive system supporting Apple Watch (HealthKit), Garmin, and Coros.
-   Manages device connection, configuration, and real-time biometric monitoring (heart rate, HRV, calories, steps).
-   Provides real-time feedback during workouts and calculates daily recovery scores.

**AI Workout Generation:**
-   Intelligent personalization based on user profiles and preferences.
-   AI-driven workout template selection, customization, and progressive adaptation.
-   Adjusts workout intensity based on recovery metrics.
-   Intelligent exercise recommendation.

**Real-time Features:**
-   Custom React hooks for workout timers.
-   Real-time progress tracking, performance metrics feedback, live heart rate monitoring, and recovery metric calculations during sessions.

**Data Seeding:**
-   Pre-populated workout categories, exercises, and training programs for professional content.
-   Includes 50+ enhanced exercises and pre-configured AI workout templates.

## External Dependencies

-   **Frontend & Backend Core:** React 18+, Express.js, TypeScript, Vite.
-   **Database:** PostgreSQL (via Neon serverless PostgreSQL), Drizzle ORM, `@neondatabase/serverless`.
-   **Authentication:** `openid-client`, Passport.js, `express-session`, `connect-pg-simple`.
-   **UI & Styling:** shadcn/ui, Radix UI, Tailwind CSS, Lucide React, `class-variance-authority`.
-   **State Management & Forms:** TanStack React Query, React Hook Form, `@hookform/resolvers`, Zod.
-   **Development Tools:** `@replit/vite-plugin-runtime-error-modal`, PostCSS, `tsx`.
-   **Utilities:** `date-fns`, `clsx`, `nanoid`, `memoizee`.